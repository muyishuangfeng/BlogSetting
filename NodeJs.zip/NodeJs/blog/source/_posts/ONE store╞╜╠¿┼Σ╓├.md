---
title: ONE store 平台配置
categories:  平台配置
---

### 前提：要使用onestore支付首先需要有onestore的账户密码

##### 配置步骤
 + 第一步：打开官网登录[ONE store](https://dev.onestore.co.kr/devpoc/index.omp)

![onestore登录.png](https://upload-images.jianshu.io/upload_images/1716569-7793e1c75921807c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 第二步：点击app然后点击注册，创建应用
  ![创建应用.png](https://upload-images.jianshu.io/upload_images/1716569-f62a0e5db740b0fb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 第三步：填写配置内容（app名称和包名）

![配置1.png](https://upload-images.jianshu.io/upload_images/1716569-b031e93347e024a7.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 第四步：填写配置详情

![配置详情.png](https://upload-images.jianshu.io/upload_images/1716569-c4b2695249ed1d8e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![配置详情1.png](https://upload-images.jianshu.io/upload_images/1716569-281de25240589d7d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![配置详情2.png](https://upload-images.jianshu.io/upload_images/1716569-3c83b5f085673410.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![配置详情3.png](https://upload-images.jianshu.io/upload_images/1716569-6ae5e11c60b8f244.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 第五步：设置商品价格
  ![商品价格.png](https://upload-images.jianshu.io/upload_images/1716569-167f0d5f61a2f52e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 第六步：上传apk
  ![上传apk.png](https://upload-images.jianshu.io/upload_images/1716569-e1576095b6ff572f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
  ![上传apk2.png](https://upload-images.jianshu.io/upload_images/1716569-81f69049ab9fcd27.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
  ![上传详情.png](https://upload-images.jianshu.io/upload_images/1716569-6f65fc4de212de2d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 第七步：应用内商品注册
  ![应用内商品注册.png](https://upload-images.jianshu.io/upload_images/1716569-13723b286926092f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
  ![应用内商品信息详情.png](https://upload-images.jianshu.io/upload_images/1716569-a1e81cd6617c748b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)