---
title: windows 下基于nginx和ffmpeg的rtmp流媒体服务器搭建
categories: ffmpeg
---

### 前提：
   最近公司要做直播方面的APP开发，刚接触到的时候是一脸懵逼状态，经过两天的采坑填坑终于搞懂了直播的流程，在此记录一下。一是怕自己忘记，另外一个是给其他人做一个参考吧。
ps：现在好多的文章千篇一律，不负责任的复制粘贴，让人摸不着头脑，并且话说的不够细致，让人很是头疼。
### 准备条件
  + [nginx-rtmp-module（带rtmp模块）](https://link.jianshu.com?t=http%3A%2F%2Fnginx-win.ecsds.eu%2Fdownload%2Fnginx%25201.7.11.3%2520Gryphon.zip)
+ [ffmpeg](https://pan.baidu.com/s/1QkD7zMgiIDhgvPI8e1GkLw) 密码：eha3
+ [screencapturer](https://pan.baidu.com/s/1MJ99kRlyaPUXkEODXMEq2w) 密码：ypgz （是一个虚拟设备，在使用FFMpeg之前，需要安装）
+ [vlc播放器](https://pan.baidu.com/s/1lEUwLWOGimEijEA4DEk03w) 密码：3yjf

   ######首先 nginx-rtmp-module是nginx的一个组件，可以自己编译生成，也可以从网上下载。需要注意的是，从nginx官网上下载的版本是不带rtmp模块的，但您可以通过： [http://nginx-win.ecsds.eu/](https://link.jianshu.com?t=http%3A%2F%2Fnginx-win.ecsds.eu%2F)找到包含rtmp组件的nginx版本，比如：nginx 1.7.8.1 Gryphon
   然后，解压按下ctrl+R键输入cmd打开命令行窗口，切换到解压的路径下，输入nginx -V 查看 nginx版本，如下图所示表示成功：
   ![查看nginx版本.png](https://upload-images.jianshu.io/upload_images/1716569-bc4e73c2489ed0ea.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ conf 下的nginx.conf配置文件（如果没有需要自己新建）
  如下图所示路径：
  ![nginx配置文件路径.png](https://upload-images.jianshu.io/upload_images/1716569-fae932939f8505b3.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
  __PS：下图是nginx配置文件，如果没有需要自己手动创建__

![nginx配置文件.png](https://upload-images.jianshu.io/upload_images/1716569-c044fd512ee17214.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ nginx.conf的配置内容

        #将以下内容拷贝到conf/nginx.conf文件中。
      #nginx进程数，建议设置为等于CPU总核心数
      worker_processes  2;
      #工作模式与连接数上限
       events {
    ​     worker_connections  8192;
       }

       rtmp_auto_push on;

      rtmp {
      server {
    ​    listen 1935;
    ​    application myapp {
    ​        live on;
    ​    }       
       }
      }
+ nginx启动方式
  ![nginx启动方式.png](https://upload-images.jianshu.io/upload_images/1716569-d2f22a0cf1def188.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
  如上图所示：切换到你的nginx安装路径下然后输入 start nginx即可启动
  __注意：__ 启动也可以输入 nginx.exe -c conf\nginx-win-rtmp.conf，这种方法带来的问题是不能优雅退出，__切记！__
  然后打开任务管理器可以看到nginx进程已经启动,如下图所示：

![nginx进程.png](https://upload-images.jianshu.io/upload_images/1716569-dcea9e15095c0afc.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
### 其次，基于ffmpeg的推拉流测试

        ffmpeg是一个自由软件，它提供了一整套多媒体的解决方案，从采集、编码、转换、播放应有尽有。
    在流媒体应用领域不借助 ffmpeg 的力量，就好比做 windows 程序而不用 Visual Studio ，做 iOSApp 
    不用 XCode 一样，需要很大的勇气。
+ ffmpeg 安装
   解压ffmpeg到指定文件夹下，我这里是在D盘的ProgramFile下的ffmpeg路径，然后将ffmpeng的bin路径添加到系统的path路径下
   ![FFMPEGbin路径.png](https://upload-images.jianshu.io/upload_images/1716569-e91f1f69260693f5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

__注意：__里面的里面的两个视频文件是我添加进去的，没有什么作用。
将D:\ProgramFile\ffmpg\ffmpeg-win64\bin 添加到环境变量的PATH后面，当然要根据你自己的安装路径配置环境变量。
+ 1、 ffmpeg实现录屏推流
  打开windows命令行在命令行下输入：

         ffmpeg -f gdigrab -i desktop -r 16 -vcodec h264 -acodec aac -f flv 
         rtmp://192.168.0.197/myapp/pc
  __注意:__ 这是一行命令行下的，没有空格，这里是方便你们查看。如下图所示，推流已经开始了。
  ![ffmpeg推流.png](https://upload-images.jianshu.io/upload_images/1716569-14bff993d2b3701d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ vlc串流配置
   打开vlc客户端，点击媒体，在下拉框选项中选中__打开网络串流__这一个选项，会弹出如下图所示的对话框，在对话框中填入刚才第二行连接（ rtmp://192.168.0.197/myapp/pc）即可，当然我这个是在局域网下面的。
   ![vlcrtmp串流配置.png](https://upload-images.jianshu.io/upload_images/1716569-c5f7e6ae5b3f0f66.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

__解释：__
+ 1、myapp为application的名字，由nginx的conf中定义
+ 2、pc为直播流的名字，由推送方定义

+ 2、ffmpeg播放视频文件
   切换到保存视频文件的路径下，我这里是在nginx路径下，如下图所示：
   ![ffmpeg视频文件.png](https://upload-images.jianshu.io/upload_images/1716569-773ed2e5c0f474d9.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

那么对应的命令就是这样写：

    ffmpeg -re -i gdiOut.avi -vcodec libx264 -acodec aac -f flv 
    rtmp://192.168.0.197:1935/myapp/home

__解释：__
+ 1、myapp为application的名字，由nginx的conf中定义
+ 2、home为直播流的名字，由推送方定义

#### 最后 
      经过两天的采坑不断尝试终于搞定了服务器这块，下来直播的还需要自己去努力完成了。我相信有志者事竟成，
    一定会死磕到底，去解决那个难题。
#### 致谢
[第一讲：win7下快速搭建媒体服务器的方法](https://www.jianshu.com/p/e5a1510de26a)
[Nginx搭建RTMP推拉流服务器](https://www.jianshu.com/p/4f96e18827e2)
另外推荐一个Android交流群493180098，如需转载请标明出处，谢谢。