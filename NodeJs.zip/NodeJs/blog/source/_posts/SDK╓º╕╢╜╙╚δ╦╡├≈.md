---
title: SDK支付接入说明
keywords: 博客文章密码
password:  123123	
abstract: 请输入密码查看文章详情
message:  输入密码，查看文章
---


### 支付流程说明

    为了保证支付的安全，sdk采用了Android支付平台（Google Play和OneStore）验证和LT服务器验证两种方式，业务流程图如下：

![TIM图片20190118111718.png](https://upload-images.jianshu.io/upload_images/1716569-d609964d9efb2856.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

#### GooglePlay 接入

(1)、客户端调用支付模块代码，由SDK向LT服务器发起一个订单请求；
(2)、拿到服务器给的订单ID后，SDK发起Google Play支付；
(3)、Google Play支付返回结果后，拿到Google Play支付成功的token信息；
(4)、SDK把Google play返回的订单号token等信息发给服务端，LT服务器向Google Play服务器校验；
(5)、服务端对Google play服务器响应数据做处理和校验订单的合法性；
(6)、通过服务器验证的结果来确定支付的结果；
(7)、支付成功回调 支付成功回调的使用方法： 需要CP服务器建立一个API供乐推服务调用 回调地址所接受的参数格式
~~~
 METHOD: POST 
 HEADER:Content-Type:application/json
~~~

#### Google Play 网络库接入说明

 + 1、接入前提 
    __手机必须支持Google 服务__

+ 2、在project 下的build 导入仓库地址

       maven {
        url "https://jitpack.io"
        credentials { username authToken }
      }
+ 3 、在 $HOME/.gradle/gradle.properties 文件下添加 token

       authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 4、在moudle下面的build文件下添加网络库依赖

        implementation 'com.github.muyishuangfeng:LTGameSDKGooglePlay-Android:1.0.3'

+ 5、在moudle的build文件夹下的android --->defaultConfig 相关配置

        defaultConfig {
        ...
           
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
      }

__1、初始化参数说明__ 

|        参数        |        类型        | 是否必须 | 说明                                       |
| :----------------: | :----------------: | :------: | :----------------------------------------- |
|       debug        |      boolean       |    否    | 是否开启debug模式                          |
|      baseUrl       |       String       |    是    | 根据具体服务器配置                         |
|      LT-AppID      |       String       |    是    | 每个应用对应的appid                        |
|      LTAppKey      |       String       |    是    | 每个应用对应的appKey                       |
|      goodsID       |       String       |    是    | 服务器配置的id                             |
|     packageId      |       String       |    是    | 每个应用的包名                             |
|       params       | Map<String,Object> |    是    | 游戏上自定义数据，可以包含充值的区服等信息 |
|    requestCode     |        int         |    是    | 支付请求码                                 |
|     productID      |       String       |    是    | 内购商品唯一ID                             |
|     googlePlay     |      boolean       |    是    | 是否添加GooglePlay支付                     |
|      payTest       |        int         |    是    | 是否是沙盒测试：1是，0否                   |
|     publicKey      |       String       |    是    | Google console配置的公钥                   |
|       Target       |        int         |    是    | 是否开启Google Play支付                    |
|   RechargeObject   |        bean        |    是    | 支付配置的参数                             |
| OnRechargeListener |     Interface      |    是    | 支付回调接口                               |
__2、支付调用方式__

+ 1、初始化（刚进入应用或者支付页面的时候配置）

        private void init() {
        LTGameOptions options = new LTGameOptions.Builder(this)
                .debug(true)
                .baseUrl(baseUrl)
                .appID(LTAppID)
                .appKey(LTAppKey)
                .publicKey(base64EncodedPublicKey)
                .baseUrl(baseUrl)
                .setParams(params)
                .payTest(1)
                .goodsID(productID, "16")
                .packageID(packageName)
                .googlePlay(true)
                .requestCode(selfRequestCode)
                .build();
        LTGameSdk.init(options);
      }

 + 2、接口回调（可以写成匿名内部类的方式也可以写成全局方式）


          OnRechargeListener mOnRechargeListener = new OnRechargeListener() {
        @Override
        public void onState(Activity activity, RechargeResult result) {
        switch (result.state) {
        case RechargeResult.STATE_RECHARGE_SUCCESS://支付成功回调
        mTxtResult.setText(result.getResultModel().getCode() + "======");
        break;
        case RechargeResult.STATE_RECHARGE_START://支付开始回调
        Log.e(TAG, "开始支付");
        break;
        case RechargeResult.STATE_RECHARGE_FAILED://支付失败回调
        Log.e(TAG, "支付错误" + result.getErrorMsg());
        break;
        }
       }
    
    };
  + 3、支付开始


          RechargeObject result = new RechargeObject();
          result.setBaseUrl(baseUrl);//baseUrl（请根据具体服务器配置）
          result.setLTAppID(LTAppID); //乐推AppID
          result.setLTAppKey(LTAppKey); //乐推AppKey
          result.setSku(productID);//商品
          result.setGoodsID("16");//商品ID（在服务器配置）
          result.setPublicKey(base64EncodedPublicKey);//公钥
          result.setmPackageID(packageName);//包名
          result.setParams(params);//自定义参数（Map<String,Object>）
          result.setPayTest(1);//是否是沙盒测试
    
                RechargeManager.recharge(GooglePlayActivity.this, Target.RECHARGE_GOOGLE,
                        result, mOnRechargeListener);

 + 4 、Google play 配置参考
    [Google Play 配置参考](https://blog.csdn.net/alex_my/article/details/82984706#2__8)

 + 5、结果码（具体以接口回调结果为准）


        1、 STATE_RECHARGE_START  开始支付
        2、 STATE_RECHARGE_SUCCESS 支付成功
        3、 STATE_RECHARGE_FAILED 支付失败
        4、order create failed:user token is empty 订单创建失败：原因是乐推token为空或者未登录


#### OneStore 接入

##### 前提：
  __手机上必须支持OneStore服务并且安装OneStore客户端__

__接入说明__
如果在project下的build文件和在 $HOME/.gradle/gradle.properties 文件下添加了 token，请忽略2、3、5配置，直接看4

+ 2、在project 下的build 导入仓库地址

        maven {
        url "https://jitpack.io"
        credentials { username authToken }
      }
+ 3 、在 $HOME/.gradle/gradle.properties 文件下添加 token

        authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 4、在moudle下面的build文件下添加网络库依赖

        implementation 'com.github.muyishuangfeng:LTGameSDKOneStore-Android:1.0.2'
+ 5、在moudle的build文件夹下的android --->defaultConfig 相关配置

        defaultConfig {
        ...
           
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
      }


__参数说明__


|        参数        |        类型        | 是否必须 | 说明                                                |
| :----------------: | :----------------: | :------: | :-------------------------------------------------- |
|       debug        |      boolean       |    否    | 是否开启debug模式                                   |
|      LT-AppID      |       String       |    是    | 每个应用对应的appid                                 |
|      LTAppKey      |       String       |    是    | 每个应用对应的appKey                                |
|      baseUrl       |       String       |    是    | 根据具体服务器配置                                  |
|     goodsType      |       String       | 商品类型 | 商品类型（管理型商品(inapp), 包月自动支付商品(auto) |
|      goodsID       |       String       |    是    | 服务器配置的id                                      |
|     packageId      |       String       |    是    | 每个应用的包名                                      |
|       params       | Map<String,Object> |    是    | 游戏上自定义数据，可以包含充值的区服等信息          |
|    requestCode     |        int         |    是    | 支付请求码                                          |
|     productID      |       String       |    是    | 内购商品唯一ID                                      |
|      oneStore      |      boolean       |    是    | 是否添加OneStore支付                                |
|      payTest       |        int         |    是    | 是否是沙盒测试：1是，0否                            |
|     publicKey      |       String       |    是    | OneStore后台配置的公钥                              |
|       Target       |        int         |    是    | 是否开启OneStore支付                                |
|   RechargeObject   |        bean        |    是    | 支付配置的参数                                      |
| OnRechargeListener |     Interface      |    是    | 支付回调接口                                        |

__2、支付调用方式__

+ 1、初始化（刚进入应用或者支付页面的时候配置）

        private void init() {
        LTGameOptions options = new LTGameOptions.Builder(this)
                .debug(true)
                .appID(LTAppID)
                .appKey(LTAppKey)
                .publicKey(PUBLIC_KEY)
                .baseUrl(baseUrl)
                .goodsType("inapp")
                .setParams(params)
                .payTest(1)
                .oneStore()
                .goodsID(productID, "11")
                .packageID(packageName)
                .requestCode(selfRequestCode)
                .build();
        LTGameSdk.init(options);
      }
+ 2、接口回调（可以写成匿名内部类的方式也可以写成全局方式）

        OnRechargeListener mOnRechargeListener = new OnRechargeListener() {
        @Override
        public void onState(Activity activity, RechargeResult result) {
            switch (result.state) {
                case RechargeResult.STATE_RECHARGE_SUCCESS:
                    mTxtResult.setText(result.getResultModel().getCode() + "======");
                    break;
                case RechargeResult.STATE_RECHARGE_START:
                    Log.e(TAG, "开始支付");
                    break;
                case RechargeResult.STATE_RECHARGE_RESULT:
                    switch (result.getResult()) {
                        case RESULT_BILLING_NEED_UPDATE: {
                            Log.e(TAG, "RESULT_BILLING_NEED_UPDATE");
                            break;
                        }
                        case RESULT_CLIENT_UN_CONNECTED: {
                            Log.e(TAG, "RESULT_CLIENT_UN_CONNECTED");
                            break;
                        }
                        case RESULT_CLIENT_CONNECTED: {
                            Log.e(TAG, "RESULT_CLIENT_CONNECTED");
                            break;
                        }
                        case RESULT_PURCHASES_REMOTE_ERROR: {
                            Log.e(TAG, "RESULT_PURCHASES_REMOTE_ERROR");
                            break;
                        }
                        case RESULT_PURCHASES_SECURITY_ERROR: {
                            Log.e(TAG, "RESULT_PURCHASES_SECURITY_ERROR");
                            break;
                        }
                        case RESULT_CLIENT_NOT_INIT: {
                            Log.e(TAG, "RESULT_CLIENT_NOT_INIT");
                            break;
                        }
                        case RESULT_BILLING_OK: {
                            Log.e(TAG, "RESULT_BILLING_OK");
                            break;
                        }
                        case RESULT_CONNECTED_NEED_UPDATE: {
                            Log.e(TAG, "RESULT_BILLING_OK");
                            break;
                        }
                        case RESULT_BILLING_REMOTE_ERROR: {
                            Log.e(TAG, "RESULT_BILLING_REMOTE_ERROR");
                            break;
                        }
                        case RESULT_BILLING_SECURITY_ERROR: {
                            Log.e(TAG, "RESULT_BILLING_SECURITY_ERROR");
                            break;
                        }
                        case IAP_ERROR_UNDEFINED_CODE: {
                            Log.e(TAG, "IAP_ERROR_UNDEFINED_CODE");
                            break;
                        }
                    }
                    break;
                case RechargeResult.STATE_RECHARGE_FAILED:
                    Log.e(TAG, "支付错误" + result.getErrorMsg());
                    break;
          
              }
           }
        
         };

  + 3、支付开始


        RechargeObject result = new RechargeObject();
        result.setBaseUrl(baseUrl);//服务器url
        result.setLTAppID(LTAppID);//乐推AppID
        result.setLTAppKey(LTAppKey);//乐推AppKey
        result.setSku(productID);//商品
        result.setGoodsID("11");//商品ID（服务器配置的）
    	result.setmGoodsType("inapp");//支付类型
        result.setPublicKey(PUBLIC_KEY);//公钥
        result.setmPackageID(packageName);//包名
        result.setParams(params);//自定义参数（Map<String,Object>）
        result.setPayTest(1);//是否是沙盒测试
        RechargeManager.recharge(OneStoreActivity.this, 	Target.RECHARGE_ONE_STORE,result, mOnRechargeListener);

+ 4、参考配置
  [OneStore 配置参考](https://dev.onestore.co.kr/devpoc/reference/view/IAP_v17_cn)
  [OneStore github参考](https://github.com/ONE-store/iap_v5/tree/onestore_iap_sample)

#### 结果码
 + 5、结果码（具体以接口回调结果为准）


       1、 STATE_RECHARGE_START  开始支付
       2、 STATE_RECHARGE_SUCCESS 支付成功
       3、order create failed:user token is empty 订单创建失败：原因是乐推token为空或者未登录
       4、 STATE_RECHARGE_FAILED 支付失败（具体结果码参考下面的结果码）
    
        RESULT_PAY_OK(0, "Payment success") 支付成功
        RESULT_USER_CANCELED(1, "User cancel") 用户取消
        RESULT_SERVICE_UNAVAILABLE(2, "service unavailable") 未连接上服务器
        RESULT_BILLING_UNAVAILABLE(3, "billing unavailable") 不支持oneStore支付
        RESULT_ITEM_UNAVAILABLE(4, "item unavailable") 商品不可用
        RESULT_DEVELOPER_ERROR(5, "developer error")开发账户异常
        RESULT_CONNECTED_SUCCESS(6, "PurchaseClient connect success") 连接成功
        RESULT_DISCONNECT_ERROR(7, "PurchaseClient Disconnect") 连接失败
        RESULT_CONNECTED_NEED_UPDATE(8, "Connected need update") oneStore客户端需要更新
        RESULT_BILLING_OK(9, "Billing success") 支持支付
        RESULT_BILLING_REMOTE_ERROR(10, "Billing Remote Connection Failed") 查询是否支持oneStore服务时提示远端服务器连接异常（未连接到服务器）
        RESULT_BILLING_SECURITY_ERROR(11, "Billing Apply State exceptions")查询是否支持oneStore服务时提示支付状态异常
       RESULT_BILLING_NEED_UPDATE(12, "Billing need update")查询是否支持oneStore服务时提示oneStore客户端需要更新
       RESULT_PURCHASES_OK(13, "Purchases success")查询购买信息成功
       RESULT_PURCHASES_REMOTE_ERROR(14, "Purchases Remote Connection Failed")查询购买信息时提示oneStore远程服务器连接异常（未连接到服务器）
       RESULT_PURCHASES_SECURITY_ERROR(15, "Purchases Apply State exceptions")查询购买信息时提示支付状态异常
       RESULT_PURCHASES_NEED_UPDATE(16, "Purchases need update")查询购买信息时提示oneStore客户端需要更新
       RESULT_CONSUME_OK(17, "Consume success")消费成功
       RESULT_CONSUME_REMOTE_ERROR(18, "Consume Remote Connection Failed")购买时提示远端服务器连接异常（未连接到oneStore）
       RESULT_CONSUME_SECURITY_ERROR(19, "Consume Apply State exceptions")购买时提示支付状态异常
       RESULT_CONSUME_NEED_UPDATE(20, "Consume need update")购买时提示oneStore客户端需要更新
       RESULT_SIGNATURE_FAILED(21, "Signature failed")签名异常
       RESULT_PURCHASES_FLOW_OK(22, "Purchases Flow success")购买成功
       RESULT_PURCHASES_FLOW_REMOTE_ERROR(23, "Purchases Flow Remote Connection 
       Failed")购买时提示远端服务器连接异常（未连接到服务器）
       RESULT_PURCHASES_FLOW_SECURITY_ERROR(24, "Purchases Flow Apply State 
        exceptions")购买时提示支付状态异常
       RESULT_PURCHASES_FLOW_NEED_UPDATE(25, "Purchases Flow need update")购买时提 
       示oneStore需要更新