---
title: Android 发布项目到jitpack详解
categories: 开源库
---



### 前提 
          最近因公司需要写了一个sdk，本想用本地库去做，但是遇到了各种问题，所以尝试着做成网络库去接入。之前一直没接触过这块，相对来说挺简单，
      但是也遇到了一些问题，在这里记录一下。


### 首先
  在开始之前先简单说一下流程：
​    1、在本地创建一个libiary工具类；
​    2、配置JitPack相关的配置信息；
​    3、排查自己工具类中的错误并上传到github；
​    4、创建release并在[JitPack](https://jitpack.io/)中编译；
​    5、在自己的项目中引用。
### 其次
  + 1、 创建一个libiary，然后上传到github（只需要上传图中红色选择框中的文件）
    ![libiary.jpg](https://upload-images.jianshu.io/upload_images/1716569-bcee6085e21ae873.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 2、在项目的build中添加配置（project级别）我这里用的JitPack版本是2.0，因为的Gradle版本是4.4，对应的JitPack是2.0，如果你的版本比较高或者比较低，需要自己查询文档，查看[JitPack对应的版本号](https://github.com/dcendents/android-maven-gradle-plugin)
   ​    ![项目build中配置.jpg](https://upload-images.jianshu.io/upload_images/1716569-0b788ae36e853ced.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![JitPack和Gradle对应的版本号.jpg](https://upload-images.jianshu.io/upload_images/1716569-8617f27d8ae5dad9.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


+ 3、在moudle中添加配置
  ![module的build中添加.jpg](https://upload-images.jianshu.io/upload_images/1716569-3a4853ef140ce49f.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


+ 4、上传到github 创建release包
  ![选择release.jpg](https://upload-images.jianshu.io/upload_images/1716569-c8dbca57a66c8850.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 5、选择release
  ![选择release.jpg](https://upload-images.jianshu.io/upload_images/1716569-3e4c175047001805.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 6、创建并发布relese  （因为我这里已经创建过了所以选择Draft a new release，如果是首次创建那么就是create new release）

![创建release.jpg](https://upload-images.jianshu.io/upload_images/1716569-d7622807b764fa92.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![发布release.jpg](https://upload-images.jianshu.io/upload_images/1716569-255edce43c2ada84.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 7、添加网址到[JitPack](https://jitpack.io/)中（复制你的项目的url）

![复制url.jpg](https://upload-images.jianshu.io/upload_images/1716569-41239f48992d565c.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 8、在Jitpack中查看

![查看.jpg](https://upload-images.jianshu.io/upload_images/1716569-ccd3395c593c70d3.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 9、点击编译
  ![点击编译.jpg](https://upload-images.jianshu.io/upload_images/1716569-0082c457336ba7b1.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 10 、编译完成
  ![编译完成.jpg](https://upload-images.jianshu.io/upload_images/1716569-0a3dc259720fdee6.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


+ 11、失败原因
  ![错误原因.jpg](https://upload-images.jianshu.io/upload_images/1716569-9d747953aeff560f.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 最后 

 查看JitPack文档，查找原因，一般都是因为你的工具类中本身的错误，所以不能通过，所以在上传之前最好自己先检查一遍错误原因。并且，遇到问题不要慌张，先看[官方文档](https://jitpack.io/docs/)排查原因。好了，就说这么多了，有问题的可以加群493180098联系我。