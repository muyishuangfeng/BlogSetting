---
title: Android Socket编程（udp）初探
categories: socket
---

### 前言
  昨天刚把socket tcp编程简单讲解了，今天趁热打铁把udp编程也讲一下。一个是为了提醒自己，坚持下去，另外还是为了提升技术打下基础。如果讲的有什么不对的还请各位指正。
###  首先
 先上图，俗话说no pic say a xx
![udp编程服务端.png](https://upload-images.jianshu.io/upload_images/1716569-021209115a4e12a5.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![udp编程客户端.png](https://upload-images.jianshu.io/upload_images/1716569-c396df1b7f103409.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
### 其次
+ 客户端代码（线程中）

      public class UdpClientThread extends Thread {
      
      //IP地址
      private String mAddress;
      //端口
      private int port;
      //发送内容
      private String msg;
      private Handler mHandler;
      
      public UdpClientThread(Handler handler, String address, int port, String msg) {
        this.mHandler = handler;
        this.mAddress = address;
        this.port = port;
        this.msg = msg;
      }
      
      @Override
      public void run() {
        super.run();
        sendSocket();
      }
      
      /**
       * 设置
       */
      private void sendSocket() {
        byte[] bytes = msg.getBytes();
        try {
            /*******************发送数据***********************/
            InetAddress address = InetAddress.getByName(mAddress);
            //1.构造数据包
            DatagramPacket packet = new DatagramPacket(bytes, 
      bytes.length, address, port);
            //2.创建数据报套接字并将其绑定到本地主机上的指定端口。
            DatagramSocket socket = new DatagramSocket();
            //3.从此套接字发送数据报包。
            socket.send(packet);
            /*******************接收数据***********************/
            //1.构造 DatagramPacket，用来接收长度为 length 的数据包。
            final byte[] bytes1 = new byte[1024];
            DatagramPacket receiverPacket = new DatagramPacket(bytes1, bytes1.length);
            socket.receive(receiverPacket);
            sendMsg(0,new String(bytes1, 0, bytes1.length));
            socket.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
      }
      
      /**
       * 发送消息
       */
      private void sendMsg(int what, Object object) {
        Message msg = new Message();
        msg.what = what;
        msg.obj = object;
        mHandler.sendMessage(msg);
       }
       }
  __说明:__这里的封装和tcp中的一样，就是换一下参数和包装类，代码中的解释都比较清楚。

+ 客户端（使用）

      public class UdpClientActivity extends AppCompatActivity
        implements View.OnClickListener {
      
      Button mBtnSend;
      String mAddress = "192.168.0.197";
      int port = 12306;
      TextView mTxtContent;
      EditText mEdtContent;
      
      @Override
      protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_udp_client);
        initView();
      }
      
      private void initView() {
        mEdtContent = findViewById(R.id.edt_udp_content);
        mBtnSend = findViewById(R.id.btn_udp_send);
        mTxtContent = findViewById(R.id.txt_udp_content);
        mBtnSend.setOnClickListener(this);
      }


      @Override
      public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_udp_send: {
                UdpClientThread mThread = new UdpClientThread(mHandler, mAddress, port,
                        mEdtContent.getText().toString());
                mThread.start();
                break;
            }
        }
      }
    
      /**
       * Handler
       */
      private Handler mHandler = new Handler(Looper.myLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0: {
                    String content = (String) msg.obj;
                    mTxtContent.setText(content);
                    break;
                }
            }
        }
      };
      }
__说明：__这里直接点击按钮调用线程使用即可，当然，也可以直接用线程池来构造参数。

+ 服务端（代码）

      public class UdpServer {
        
          /**
           * @param args
           */
            public static void main(String[] args) {
            while (true) {
          	 getMsg();
            }
            }
        
          /**
           * 获取信息
           */
           
             private static void getMsg() {
             try {
          ​	byte[] buf = new byte[1024];
          ​	// 一、接收数据
          ​	// 1、创建接收数据的数据包
          ​	DatagramPacket packet = new DatagramPacket(buf, buf.length);
          ​	// 2.创建UPD 的 socket
          ​	DatagramSocket socket = new DatagramSocket(12306);
          ​	// 3、接收数据
          ​	System.out.println("服务端开始监听！~~~~");
          ​	socket.receive(packet);
          ​	// 4、处理数据
          ​	System.out.println("服务端：" + new String(buf, 0, buf.length));
        
          	// 二、返回数据
          	DatagramPacket packet2 = new DatagramPacket(buf, buf.length,
          			packet.getAddress(), packet.getPort());
          	socket.send(packet2);
          	socket.close();
          } catch (Exception e) {
          ​	e.printStackTrace();
          }
        
       }
        
      }
### 最后
  唠叨一下，做事一定要善始善终，做人一定要诚信（ps：最近遇到了一个不诚信的公司，offer发了之后，第二天告诉我不用去了，问过原因之后，人事和老板助理回复还不一样，这样就有点好玩了，真的是越想越生气。尤其是对于我这种对诚信比较看重的人，真的是不能忍。特别痛恨那种答应别人却做不到的人，要不就别答应，要不就做到。我一般答应别人的事情，一定会做到，不管我要付出什么，起码我兑现了自己的承诺。）。发了一顿牢骚，还请各位看官见谅。
### 致谢
 [Android网络编程之--Socket编程](https://www.jianshu.com/p/fb4dfab4eec1)