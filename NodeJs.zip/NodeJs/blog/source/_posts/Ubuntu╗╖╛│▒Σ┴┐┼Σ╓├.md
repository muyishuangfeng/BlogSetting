---
title: Ubuntu环境变量配置
categories: Linux
---

#前提： 
​       之前一直想用ubuntu，但是现在大部分编程都是在windows上，所以很少用。但是现在需要编译ffmpeg，
​    奈何windows上遇到了各种bug，不好处理，索性直接给自己的老人机上安装了ubuntu系统。今天主要是针对
​    小白来讲解一下ubuntu配置jdk和ndk环境变量的，还请给为大佬绕道轻点打脸。

###首先
__本篇ubuntu版本是16.04，JDK版本是1.8和NDK版本是android-ndk-r12b，下面的是链接地址__
+ 下载[Linux版本的JDK](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html?utm_source=androiddevtools&utm_medium=website)
+ 下载 [Linux版本的NDK](https://dl.google.com/android/repository/android-ndk-r12b-linux-x86_64.zip?utm_source=androiddevtools&utm_medium=website)
+ 下载 [Linux版本的Android Studio](https://dl.google.com/dl/android/studio/ide-zips/3.0.1.0/android-studio-ide-171.4443003-linux.zip?utm_source=androiddevtools&utm_medium=website)
  ###其次
 + 使用crtl+alt+t切换到终端，然后切换到你的jdk下载地址，我的下载地址在“/home/silence/下载” 路径下如下图所示，当然我这个是已经安装过的了目前没有JDK和NDK安装包
    #####1、JDK安装
    ![ubuntuJDK下载路径.jpg](https://upload-images.jianshu.io/upload_images/1716569-1c9bdab5e1dcf735.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 选择索要下载的Linux安装包，我这里使用的是jdk-8u161-linux-x64.tar.gz
  ![JDK版本.png](https://upload-images.jianshu.io/upload_images/1716569-11506c5412342c39.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
+ 在usr/lib下新建jdk包，并且移动jdk-8u161-linux-x64.tar.gz并且解压

       1、在终端输入sudo mkdir /usr/lib/jdk新建jdk包
       2、移动jdk-8u161-linux-x64.tar.gz到jdk包下，在终端输入
          sudo mv jdk-8u161-linux-x64.tar.gz /usr/lib/jdk
       3、解压jdk-8u161-linux-x64.tar.gz包 ，在终端输入
          sudo tar zxvf jdk-8u161-linux-x64.tar.gz 解压之后得到 
          jdk1.8.0_161 包
+ 配置环境变量

       1、在终端输入sudo gedit ~/.bashrc 打开~/.bashrc文件其中
         【~/】表示/home/用户名,如下图所示，其中sudo是超级用户需要输入密码

     ![终端打开bashrc.jpg](https://upload-images.jianshu.io/upload_images/1716569-1127ecd1fabcb74b.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

       2、在~/.bashrc的最下面输入（如下图所示）
          export JAVA_HOME=/usr/lib/jdk/jdk1.8.0_161  
          export JRE_HOME=${JAVA_HOME}/jre  
          export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib  
          export PATH=${JAVA_HOME}/bin:$PATH

![bashrc输入环境变量.jpg](https://upload-images.jianshu.io/upload_images/1716569-4e00ca7cb878ae89.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

     3、在终端输入source ~/.bashrc是环境变量生效（如下图）
![环境变量生效.jpg](https://upload-images.jianshu.io/upload_images/1716569-9bedfee9c5c728fa.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
__当然，我这里已经把JDK环境和NDK的环境变量都已经配置了__
+ 其中/usr/lib/jdk表示的就是刚才新建的那个文件夹
+ 后面的JRE_HOME、CLASSPATH、PATH依次写入即可。
+ 然后在终端输入java -version如下图所示即表示成功（如下图所示）。
  ![JDK成功图.jpg](https://upload-images.jianshu.io/upload_images/1716569-bb67867f4db6f4bd.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
  #####2、NDK安装

 + 首先下载NDK包，我这里使用的是[android-ndk-r12b-linux-x86_64.zip](https://dl.google.com/android/repository/android-ndk-r12b-linux-x86_64.zip?utm_source=androiddevtools&utm_medium=website)下载之后
    切换到下载路径下即----- /home/silence/下载
+ 新建NDK安装路径，我这里是先安装了 [android-studio-ide-171.4443003-linux.zip](https://dl.google.com/dl/android/studio/ide-zips/3.0.1.0/android-studio-ide-171.4443003-linux.zip?utm_source=androiddevtools&utm_medium=website)

      1、会在/home/silence/Android下生成一个Sdk包，把NDK包移动到/home/silence/Android路径下，
      2、在终端输入 sudo mv android-studio-ide-171.4443003-linux.zip即可，
      然后终端切换到Android路径下，即cd /home/silence/Android 
      3、输入 ls -all 即可看到/home/silence/Android路径下所有的文件，
      4、再对android-studio-ide-171.4443003-linux.zip进行解压，在终端输入 
      sudo unzip android-studio-ide-171.4443003-linux.zip即可得到一个
      Android-studio 包 
      5、切换到android-studio/bin目录下打开.studio.sh即可打开android-studio
       在终端输入 cd android-studio/bin,然后再输入 sudo ./studio.sh即可，这样    
       就可以打开android studio
      6、解压NDK包，在终端输入 sudo unzip android-ndk-r12b-linux-
         x86_64.zip即可得到一个 包名为android-ndk-r12b的包。
      7、配置NDK环境变量，在终端输入 sudo ~/.bashrc打开~/.bashrc文件，
         在最后输入多需要的环境变量路径，然后保存关闭。
      8、使环境变量生效，在终端输入source ~/.bashrc即可。
      9、验证环境变量成功与否，在终端输入 ndk-build -v,如下图所示则配置成功。
  ![NDK成功图.jpg](https://upload-images.jianshu.io/upload_images/1716569-38746433544edec2.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

### 致谢
  [Android NDK开发（三） 在Linux环境下编译FFmpeg](https://www.jianshu.com/p/9d8322e5de7f)
[AndroidDevTools](http://www.androiddevtools.cn/index.html)
### 总结
         配置环境变量总体来说还是比较顺利的，但是当刚接触到新东西的时候会有所胆怯，但是当我们真正战胜
      自己的胆怯而完成的时候却又是另一番景象，所以遇到问题还是迎难而上吧。推荐一个Android交流群，群号
      493180098。还有一句，请尊重作者的辛苦劳动，转载请标明出处，谢谢。
 [我的简书](https://www.jianshu.com/u/1e2eec6f972c)
[我的掘金](https://juejin.im/user/58df0abf61ff4b006b115e43)
[我的github](https://github.com/muyishuangfeng)
[我的个人博客](https://muyishuangfeng.github.io/)
__小弟就厚着脸皮说欢迎关注哈__