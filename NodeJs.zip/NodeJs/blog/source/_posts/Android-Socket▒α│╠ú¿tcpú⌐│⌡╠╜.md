---
title: Android Socket编程（tcp）初探
categories: socket
---

### 前言
之前一直对socket编程这块比较陌生，并且在刚开始工作的时候比较抗拒。其实，都是因为当时自己比较菜，这块比较难处理，在舒适区呆的习惯了。所以，还是应该让自己走出舒适区，多接触一些陌生的区域。
### 首先
 在将socket编程前，先了解一下socket的知识。

#### TCP/IP协议

我们举个不恰当的例子：比如通过QQ和服务器进行通信，都需要哪些东西呢？
两台电脑建立连接进行通信，需要知道双方的地址（也就是IP地址）；知道两台电脑的IP地址之后，我们还需要知道我发送到目标电脑的目标软件（使用端口标记）。如果两台电脑连接成功之后就可以进行通信了。
那么这些东西如何进行规定的呢，这就需要有一定的通讯协议，比如我和张三约定在西安钟楼见面，然后两个人都必须手拿一把白色茉莉花。只有当我们双方见面并且看到对方拿的是我们之前商量好的白色茉莉花才可以进行通讯。那么，这个白色茉莉花就是我们之间的约定，也就是socket中的协议。大家都使用这个协议，统一成一个规范，这样符合这个规范的各种设备之间能够进行兼容性的通信。
最为广泛的的协议就是OSI协议和TCP/IP协议了，但是OSI协议较为繁琐，未推广（想了解的自己Google）。反而TCP/IP(transfer control protocol/internet protocol,传输控制协议/网际协议)协议简单明了，得到现今的广泛使用。
![协议.png](https://upload-images.jianshu.io/upload_images/1716569-ff87e4994d2b6574.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![协议传输示意图.jpg](https://upload-images.jianshu.io/upload_images/1716569-3fa7b4355b1c03e6.jpg?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)



### 其次
 说了那么多的文字性描述，那么接下来看看我们的基于TCP协议的客户端和服务端实现

+ 客户端图片
   这里封装到了线程中，如果需要修改，那么自行修改，小可这里只是抛砖引玉，废话不说先上图
   ![tcp客户端.png](https://upload-images.jianshu.io/upload_images/1716569-a0dfc130f99a50e6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 客户端代码（线程中）
  __代码中的注释比较详细，我这里就不逐一解释了__

      public class TcpClientThread extends Thread {
      
      //IP地址
      private String address;
      //端口
      private int port;
      //发送内容
      private String msg;
      private Handler mHandler;
      
      public TcpClientThread(Handler handler, String address, int port, String msg) {
        this.mHandler = handler;
        this.address = address;
        this.port = port;
        this.msg = msg;
      }
      
      @Override
      public void run() {
        super.run();
        sendSocket();
      }
      
      /**
       * 设置
       */
      private void sendSocket() {
        InputStreamReader reader = null;
        BufferedReader bufReader = null;
        Socket socket = null;
        try {
            //1.创建监听指定服务器地址以及指定服务器监听的端口号
            //IP地址，端口号
            socket = new Socket(address, port);
            // 2.拿到客户端的socket对象的输出流发送给服务器数据
            OutputStream os = socket.getOutputStream();
            //写入要发送给服务器的数据
            os.write(msg.getBytes());
            os.flush();
            socket.shutdownOutput();
            //拿到socket的输入流，这里存储的是服务器返回的数据
            InputStream is = socket.getInputStream();
            //解析服务器返回的数据
            reader = new InputStreamReader(is);
            bufReader = new BufferedReader(reader);
            String s = null;
            final StringBuffer sb = new StringBuffer();
            while ((s = bufReader.readLine()) != null) {
                sb.append(s);
            }
            sendMsg(0, sb.toString());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally { //3、关闭IO资源
            try {
                if (bufReader != null)
                    bufReader.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            try {
                if (socket != null)
                    socket.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
      
        }
       }
      
      /**
       * 发送消息
       */
      private void sendMsg(int what, Object object) {
        Message msg = new Message();
        msg.what = what;
        msg.obj = object;
        mHandler.sendMessage(msg);
      }
      }
+ 客户端（Activity中使用）

      public class TcpClientActivity extends AppCompatActivity 
         implements   View.OnClickListener {
      
        EditText mEdtContent;
       TextView mTxtContent;
       Button mBtnSend;
       String address = "192.168.0.197";
       int port = 12345;


       @Override
       protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tcpclient);
        initView();
       }
    
      private void initView() {
        mEdtContent = findViewById(R.id.edt_content);
        mBtnSend = findViewById(R.id.btn_send);
        mTxtContent = findViewById(R.id.txt_content);
        mBtnSend.setOnClickListener(this);
      }
    
       @Override
       public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_send: {//发送
                TcpClientThread mThread = new TcpClientThread(mHandler, address, port,
                        mEdtContent.getText().toString());
                mThread.start();
    
                break;
            }
        }
      }
    
      /**
       * Handler
       */
      private Handler mHandler = new Handler(Looper.myLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0: {
                    String content= (String) msg.obj;
                    mTxtContent.setText(content);
                    break;
                }
            }
        }
      };
      }
+ 服务端（图片）

   ![tcp服务端.png](https://upload-images.jianshu.io/upload_images/1716569-603d01c240080afa.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

+ 服务端（代码-->线程中）

      public class TcpServerThread extends Thread {
     private Socket socket;

    /**
     * 初始化
     * 
     * @param socket
          */
            public TcpServerThread(Socket socket) {
          this.socket = socket;
            }

    @Override
    public void run() {
  ​	super.run();

  	InputStreamReader reader = null;
  	BufferedReader bufReader = null;
  	OutputStream os = null;
  	try {
  		reader = new InputStreamReader(socket.getInputStream());
  		bufReader = new BufferedReader(reader);
  		String s = null;
  		StringBuffer sb = new StringBuffer();
  		while ((s = bufReader.readLine()) != null) {
  			sb.append(s);
  		}
  		System.out.println("服务器：" + sb.toString());
  		// 关闭输入流
  		socket.shutdownInput();
  	
  		// 返回给客户端数据
  		os = socket.getOutputStream();
  		os.write(("我是服务端,客户端发给我的数据就是：" + sb.toString()).getBytes());
  		os.flush();
  		socket.shutdownOutput();
  	} catch (IOException e2) {
  		e2.printStackTrace();
  	} finally {// 关闭IO资源
  		if (reader != null) {
  			try {
  				reader.close();
  			} catch (IOException e) {
  				e.printStackTrace();
  			}
  		}
  	
  		if (bufReader != null) {
  			try {
  				bufReader.close();
  			} catch (IOException e) {
  				e.printStackTrace();
  			}
  		}
  		if (os != null) {
  			try {
  				os.close();
  			} catch (IOException e) {
  				e.printStackTrace();
  			}
  		}
  	  }
		
  	}
		
  	}
+ 服务端（调用）

      public class TcpServer {
        
         /**
          * @param args
          */
            public static void main(String[] args) {
            try {
          ​ 	@SuppressWarnings("resource")
          ​	ServerSocket serverSocket = new ServerSocket(12345);
          ​	while (true) {
          ​		System.out.println("Server开始~~~监听~~~");
          ​		// accept方法会阻塞，直到有客户端与之建立连接
          ​		Socket socket = serverSocket.accept();
          ​		TcpServerThread serverThread = new TcpServerThread(socket);
          ​		serverThread.start();
          ​	}
          } catch (IOException e) {
          ​	e.printStackTrace();
            }
            }
        
        }
+ 说明
  这里用了一个while循环，然后就可以无限接收客户端发送的数据，如果把while中的条件改成你需要的，就会实现你所需要的东西。
### 最后
   刚开始写的时候自己也是一脸懵逼，克服了重重困难才做了出来，当然这种也不是最终的，没有加入自己的协议。需要根据自己的实际需求做出来，然后改成自己的需要的东西。
### 致谢
[Android网络编程之--Socket编程](https://www.jianshu.com/p/fb4dfab4eec1)