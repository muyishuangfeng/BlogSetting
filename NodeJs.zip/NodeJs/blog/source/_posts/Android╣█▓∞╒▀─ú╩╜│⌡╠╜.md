---
title: Android观察者模式初探
categories: Android
---

### 前提
​    好久都没更新了，最近因为看设计模式，因为首先看的是观察者模式。对观察者模式有了一个比较全面的理解。今天斗胆来说一下自己的理解，还望各位看官老爷轻点打脸。
###话不多说先看图


![观察者模式.png](http://upload-images.jianshu.io/upload_images/1716569-116cd2cc32a17f6b.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

   _ 容小可解释一下,在这个界面中，要实现在一个输入框中写入文本然后点击设置按钮，实现下面的TextView实时改变的功能。到这里也许有人会问了可以用TextWatcher实现啊，对的，因为TextWatcher中运用的就是观察者模式（其实Android中运用观察者模式的地方很多）来看正文。_

#释义
###观察者模式 
​      定义对象间的一种一个(Subject)对多(Observer)的依赖关系，当一个对象的状态发生改变时，所有依赖于它的 对象都得到通知并被自动更新 。
###适用性： 
​      1. 当一个抽象模型有两个方面，其中一个方面依赖于另一方面 将这两者封装成独立的对象中以使它们可以各自独立的改变和服用 。
​      2. 当对一个对象的改变需要同时改变其他对象，而不知道具体有多少对象有待改变 。
​      3. 当一个对象必须通知其它对象，而它又不能假定其它对象是谁 
 ### 参与者： 
      1. Subject（目标） 
         目标知道它的观察者，可以有任意多个观察者观察同一个目标提供注册和删除观察者对象的接口 
      2. Observer（观察者） 
         为那些在目标发生改变时需获得通知的对象定义个更新的接口 
      3. ConcreteSubject（具体目标） 
         将有关状态存入各ConcreteObserver对象 当它的状态发送改变时，向它的各个观察者发出通知 
      4. ConcreteObserver（具体观察者） 
    维护一个指向ConcreteObserver对象的引用存储有关状态，这些状态应与目标的状态保持一致 实现Observer的更新接口是自身状态与目标的状态保持一致 
#实例
​    说了那么多的名词解释，估计各位看官都有点蒙圈了，别着急，让本人用一个实例给你们演示一番，相信聪明的你们一定会看懂的。
 #### 1、首先是观察者Observer

    public class MyObserver implements Observer {
    
    private Handler mHandler;
    private String name;
    public MyObserver() {
    }
    
    public MyObserver(Handler handler, String name) {
    	this.mHandler = handler;
    	this.name = name;
    }
    
    public String getName() {
    	return name;
    }
    
    public void setName(String name) {
    	this.name = name;
    }
    
    @Override
    public void update(Observable observable, Object data) {
    	sendMessage(MsgBox.MSG_UPDATE_SUCCESS, data);
    }
       /**
        *发送消息
        */
    private void sendMessage(int what, Object object) {
    	Message msg = new Message();
    	msg.what = what;
    	msg.obj = object;
    	mHandler.sendMessage(msg);
    }
    }
#### 2、被观察者Observable
     /**
     * 被观察者
      * 
      * @author Silence
      * 
     */
     public class MyObserable extends Observable {
    
    public void postNewPublication(String content) {
    	setChanged();
    	notifyObservers(content);
    }
    }
#### 3、在Activity中使用
     public class SecondActivity extends BaseActivity {
 	// 观察者
 	private Button mBtnGet, mBtnSetting;
 	private TextView mTxtName;
 	private EditText mEdtContent;
 	// 观察者
 	private MyObserver mObserver;
 	// 被观察者
 	MyObserable obserable = new MyObserable();

	@Override
	protected void setContentView() {
		setContentView(R.layout.activity_second);
	}
	
	@Override
	protected void initView() {
		mBtnGet = $(R.id.btn_get);
		mBtnSetting = $(R.id.btn_setting);
		mTxtName = $(R.id.txt_name);
		mEdtContent = $(R.id.edt_content);
	
	}
	
	@Override
	protected void initData() {
	
	}
	
	@Override
	protected void setListener() {
		mBtnGet.setOnClickListener(this);
		mBtnSetting.setOnClickListener(this);
	}
	
	@Override
	protected void initLitener(View view) {
		switch (view.getId()) {
		case R.id.btn_get: {
			getData();
		}
	
			break;
		case R.id.btn_setting: {
			setData();
		}
	
			break;
	
		default:
			break;
		}
	}
	
	/**
	 * 设置数据
	 */
	protected void setData() {
		String content = mEdtContent.getText().toString().trim();
		mObserver = new MyObserver(mHandler, content);
		obserable.addObserver(mObserver);
		obserable.postNewPublication(content);
	}
	
	/**
	 * 获取数据
	 */
	protected void getData() {
	
		startActivity(new Intent(SecondActivity.this, ThirdActivity.class));
	}
	
	/**
	 * Handler
	 */
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			switch (msg.what) {
			case MsgBox.MSG_UPDATE_SUCCESS:
				String name = (String) msg.obj;
				mTxtName.setText(name);
				break;
	
			default:
				break;
			}
		};
	};
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		obserable.deleteObserver(mObserver);
	}
	
	}
#感谢
[Android设计模式之观察者模式](http://blog.csdn.net/fangchongbory/article/details/7774044)
[Android设计模式（十一）-观察者模式](http://www.jianshu.com/p/316147958b67)