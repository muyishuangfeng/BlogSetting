---
title: Google 平台配置
categories: 平台配置
---

#### Google审核流程： 

[Google APIs后台 地址](https://console.developers.google.com/)
步骤：
1、进入Google APIs 后台之后，选择一个专案（即创建好的应用名称）点击侧边栏，选择“API 管理员”。![](https://upload-images.jianshu.io/upload_images/1716569-764d7017bfd58ff8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)



2、点选择侧边栏“凭据”， 进入“OAuth 同意屏幕”填入自己的APP名称进入“向使用者展示的产品名称”，并填写其他信息。

![image](https://upload-images.jianshu.io/upload_images/1716569-951c3e40998b7599.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)



3、点选择侧边栏“凭据”，进入“凭据”菜单栏，点击“创建凭据”－－》“OAuth 客户端ID”。
![image](https://upload-images.jianshu.io/upload_images/1716569-0ffb701f44caf549.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)



4、配置信息 ，包名和签名文件的SHA1要与项目中的保持一致，并获得Client ID。
![Google凭据.png](https://upload-images.jianshu.io/upload_images/1716569-6e5b80f55fa5b30c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)




以下截图处就是ClientID

![clientID.png](https://upload-images.jianshu.io/upload_images/1716569-3670c9e6ff906853.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)




5、点选择侧边栏“信息中心”，开启 API和服务。Google API后台配置就完成了。
![image](https://upload-images.jianshu.io/upload_images/1716569-c200265dfdb5317d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)




![启用服务.png](https://upload-images.jianshu.io/upload_images/1716569-83f4221e9e8e5a6a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)