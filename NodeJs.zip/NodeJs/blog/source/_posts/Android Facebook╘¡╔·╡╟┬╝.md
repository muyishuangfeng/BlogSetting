---
title: Android Facebook 原生登录
categories: 登录
---

### 前言：

         在写这篇文章之前先吐槽一下自己的英文水平，之前一直没感觉，因为做的项目都是国内的项目，很少看英文文档。但是，自从换了一个工作之后，
      做的是国外的项目。并且，写了给第三方写了一个SDK，需要使用Google登录和Facebook登录。那么，就必须用原生登录，说到原生登录，那么就逃不掉要看
      英文文档。看了英文文档之后才感觉自己的英文是多么的差劲。好了，废话不多说，我们进入今天的正题。如何使用Facebook登录。

### 首先

   当然是查看[官方文档](https://developers.facebook.com/docs/facebook-login/android)了，官方文档介绍的很清楚，并且更新比较及时。如果你不太想看英文文档，而去各种百度。那么，你可能会遇到各种各样的问题。

+ 1、引入Facebook的在线依赖

      //facebook登录
      implementation 'com.facebook.android:facebook-login:4.39.0'
+ 2、在清单文件中配置在Facebook申请的 appID和scheme

      <!-- facebook登录 -->
        <meta-data
            android:name="com.facebook.sdk.ApplicationId"
            android:value="@string/facebook_app_id" />
      
        <activity
            android:name="com.facebook.FacebookActivity"
            android:configChanges="keyboard|keyboardHidden|screenLayout|screenSize|orientation"
            android:label="@string/app_name" />
        <activity
            android:name="com.facebook.CustomTabActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
      
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
      
                <data android:scheme="@string/fb_login_protocol_scheme" />
            </intent-filter>
        </activity>

 __注意：__ 上面的 @string/facebook_app_id 换成你在facebook申请的AppID，@string/fb_login_protocol_scheme 换成Facebook给你分配的scheme。

### 其次

     上面的配置算是搞定了，那么就是代码的编写了，我这里为了方便，所以封装了一个Facebook登录类。

   + 1、首先看工具类的封装

   1)、Facebook登录封装类
​    
​     private static CallbackManager mFaceBookCallBack;
​     private static FaceBookLoginManager sInstance;
​    
​     private FaceBookLoginManager() {
​    
​     }
​    
​    /**
​     * 单例
​     *
​     * @return
​     */
​    public static FaceBookLoginManager getInstance() {
​        if (sInstance == null) {
​            synchronized (FaceBookLoginManager.class) {
​                if (sInstance == null) {
​                    sInstance = new FaceBookLoginManager();
​    
                }
            }
        }
        return sInstance;
    }


    /**
     * 开始
     *
     * @param context
     */
    public void faceBookLogin(Context context) {
        LoginManager.getInstance()
                .logInWithReadPermissions((Activity) context,
                        Arrays.asList("public_profile"));
    }


    /**
     * 初始化
     */
    public void initFaceBook(final Context context,
                              final OnLoginSuccessListener mListener) {
        mFaceBookCallBack = CallbackManager.Factory.create();
        if (mFaceBookCallBack != null) {
            LoginManager.getInstance().registerCallback(mFaceBookCallBack,
                    new FacebookCallback<LoginResult>() {
                        @Override
                        public void onSuccess(LoginResult loginResult) {
                            if (loginResult != null) {
                               if(mListener=null){
                                mListener.onSuccess(result);
                                    }
                              
                            }
    
                        }
    
                        @Override
                        public void onCancel() {
                           if(mListener=null){
                                mListener.onCancel();
                                    }
                        }
    
                        @Override
                        public void onError(FacebookException error) {
                           if(mListener=null){
                                mListener.onError(error);
                                    }
                        }
                    });
    
        }
    }


    /**
     * 设置登录结果回调
     *
     * @param requestCode 请求码
     * @param resultCode  结果码
     * @param data        数据
     */
    public void setOnActivityResult(int requestCode, int resultCode, Intent data) {
        if (mFaceBookCallBack != null) {
            mFaceBookCallBack.onActivityResult(requestCode, resultCode, data);
        }
    }

2）、接口

    public interface OnLoginSuccessListener {
    
    void OnSuccess(LoginResult result);
    
    void onCancel();
    
    void onError(FacebookException error);
    }
3）、LoginResult 类

    public class LoginResult {
    private final AccessToken accessToken;
    private final Set<String> recentlyGrantedPermissions;
    private final Set<String> recentlyDeniedPermissions;
    
    /**
     * The constructor.
     *
     * @param accessToken                The new access token.
     * @param recentlyGrantedPermissions The recently granted permissions.
     * @param recentlyDeniedPermissions  The recently denied permissions.
     */
    public LoginResult(
            AccessToken accessToken,
            Set<String> recentlyGrantedPermissions,
            Set<String> recentlyDeniedPermissions) {
        this.accessToken = accessToken;
        this.recentlyGrantedPermissions = recentlyGrantedPermissions;
        this.recentlyDeniedPermissions = recentlyDeniedPermissions;
    }
    
    /**
     * Getter for the new access token.
     * @return the new access token.
     */
    public AccessToken getAccessToken() {
        return accessToken;
    }
    
    /**
     * Getter for the recently granted permissions.
     * @return the recently granted permissions.
     */
    public Set<String> getRecentlyGrantedPermissions() {
        return recentlyGrantedPermissions;
    }
    
    /**
     * Getter for the recently denied permissions.
     * @return the recently denied permissions.
     */
    public Set<String> getRecentlyDeniedPermissions() {
        return recentlyDeniedPermissions;
    }
    }
+ 2、如何使用呢？


 1）、初始化Facebook

    FaceBookLoginManager.getInstance().initFaceBook(this,
                new OnLoginSuccessListener() {
                    @Override
                    public void onSuccess(LoginResult result) {
                       
                    }
    
                    @Override
                    public void onError(FacebookException ex) {
                        
                    }
    
                    @Override
                    public void onCancel() {
                      
                    }
    
                });
  2)、设置回调

    /**
     * 设置登录结果回调
     *
     * @param requestCode 请求码
     * @param resultCode  结果码
     * @param data        数据
     */
    public void setOnActivityResult(int requestCode, int resultCode, Intent data) {
        if (mFaceBookCallBack != null) {
            mFaceBookCallBack.onActivityResult(requestCode, resultCode, data);
        }
    }

3）、调用登录

        mBtnSend=findViewById(R.id.btn_send);
        mBtnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             FaceBookLoginManager.getInstance().faceBookLogin(MainActivity.this);
            }
        });

### 最后
     到此，Facebook的登录就完成了，当然，上面的工具类还可以进一步封装，并且整理成一个在线依赖库。

如果你对打包成在线依赖库不太熟的话，建议你去看我的另一篇文章[Android 发布项目到jitpack详解](https://www.jianshu.com/p/d287db9fae38)。