---
title: Android 自定义接口
categories: Android
---


### 前提
 **1、各位看官大家好，小可今天又来装，啊呸，又来写干货来了。在自定义Android接口之前先要搞清楚什么是接口**
**2、接口定义**
 - 大家都知道Android是基于Java语言开发的，嗯，之前是，当然现在也有Kotin，今天主要讲解Java方面。
- 接口（英文：Interface），在JAVA编程语言中是一个抽象类型，是抽象方法的集合，接口通常以interface来声明。一个类通过继承接口的方式，从而来继承接口的抽象方法。
- 接口并不是类，编写接口的方式和类很相似，但是它们属于不同的概念。类描述对象的属性和方法。接口则包含类要实现的方法。除非实现接口的类是抽象类，否则该类要定义接口中的所有方法。
- 接口无法被实例化，但是可以被实现。一个实现接口的类，必须实现接口内所描述的所有方法，否则就必须声明为抽象类。另外，在 Java 中，接口类型可用来声明一个变量，他们可以成为一个空指针，或是被绑定在一个以此接口实现的对象。
  **3、实现方法**
- 相信上面对接口的说明大家都可以理解，但是，自定义接口又是什么样子的呢，相信还是比较抽象的，所以今天就小可就在此举一个例子来介绍一下
  ###首先
 - 先分析一下，我们今天要自定义的接口要有什么诉求（**即要实现什么功能**）自定义接口是为了更好的传递我们想要传递的值。
- 大家都知道Recyclerview没有自带点击事件，今天就以Recyclerview的点击事件为例，来介绍一下自定义接口
- 定义一个接口类
  ​         

      public interface OnItemClickListener {
        //第一个参数是适配器的item，第二个参数是位置
        - 短按事件
       void OnItemClick(View view,int position);
          长按事件
       void OnItemLongClick(View view,int position);
     }

### 其次
  - 要实现Recyclerview的点击事件，当然要定义一个适配器了


      public class CustomAdapter extends RecyclerView.Adapter
        <CustomAdapter.CustomViewHolder> {
    
       private List<CustomBean> mList;
       private Context mContext;
       private LayoutInflater mInflater;
       private OnItemClickListener mOnItemClickListener;
    
    public CustomAdapter(List<CustomBean> mList, Context context) {
        this.mList = mList;
        this.mContext = context;
        this.mInflater = LayoutInflater.from(mContext);
    }
    
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup 
    parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_custom_layout, 
    parent, false);
        CustomViewHolder viewHolder = new CustomViewHolder(view);
        return viewHolder;
    }
    
    @Override
    public void onBindViewHolder( CustomViewHolder holder, int position) {
        holder.mTxtItemTitle.setText(mList.get(position).getTitle());
        holder.mTxtItemContent.setText(mList.get(position).getContent());
        //设置点击事件
       setUIEvent(holder);
    }
    
    @Override
    public int getItemCount() {
        return mList==null?0:mList.size();
    }
    
    class CustomViewHolder extends RecyclerView.ViewHolder {
    
        TextView mTxtItemTitle, mTxtItemContent;
    
        public CustomViewHolder(View itemView) {
            super(itemView);
            mTxtItemTitle = itemView.findViewById(R.id.txt_item_title);
            mTxtItemContent = itemView.findViewById(R.id.txt_item_content);
        }
    }
    
    /**
     * 设置点击事件
     * @param holder
     */
    public void setUIEvent(final CustomViewHolder holder){
        //点击事假，首先判断是否为空，不为空的时候再进行操作
        if (mOnItemClickListener != null) {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int layoutPosition = holder.getLayoutPosition();
                    mOnItemClickListener.OnItemClick(holder.itemView, layoutPosition);
                }
            });
            holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    int layoutPosition = holder.getLayoutPosition();
                    mOnItemClickListener.OnItemLongClick(holder.itemView, layoutPosition);
                    return false;
                }
            });
        }
    }
    
    /**
     * 提供给Activity或者Fragment调用的
     *
     * @param onItemClickListener
     */
    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.mOnItemClickListener = onItemClickListener;
    }
     }
**在适配器里面对接口的调用已经很清晰明了了，相信各位看官已经看懂了吧。**

### 再次

- 当然，现在就是在Activity里面怎么实现接口回调了

      public class ThirdActivity extends BaseActivity implements 
       OnItemClickListener{
      
       RecyclerView mRecyclerView;
       List<CustomBean>mList=new ArrayList<>();
       CustomAdapter mAdapter;
      
      @Override
      public void setContentView() {
        setContentView(R.layout.activity_third);
      }
      
      @Override
      public void initView() {
        mRecyclerView = $(R.id.recyclerView);
        mRecyclerView.setLayoutManager(new 
      LinearLayoutManager(this));
        mAdapter= new CustomAdapter(mList,this);
        mAdapter.setOnItemClickListener(this);
        mRecyclerView.setAdapter(mAdapter);
        
       }
      
       @Override
      public void initData() {
      
        }
      
      @Override
       public void initClick(View view) {
      
       }
      
      @Override
      public void setListener() {
      
      }
      
      @Override
      public void OnItemClick(View view, int position) {
        ToastUtils.showMessage(this,getResources().getString(R.string.click_item));
      }
      
      @Override
      public void OnItemLongClick(View view, int position) {
       
      }
      }
- 到此，自定义接口形成了一个圆满的回调，当然还有其他回调写法，再举一个例子讲解一下。依然是在适配器中实现

![适配器图.png](http://upload-images.jianshu.io/upload_images/1716569-036829b6b279f332.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
- 来看图，这个就是上面实现的适配器图片，然后我们想对**内容**这个字段加上点击事件该怎么做呢？相信聪明如你的看官已经想到了。即对**内容**这个TextView加上点击事件即可，话不多说上代码：

      /**
        * 点击内容的接口
        */
      public interface OnItemContentClickListener{
       //点击事件
        void OnContentClick(int position);
        //长按事件
        void OnContentLongClick(int position);
      }
- 由上面的接口可以看到此接口主要实现了点击内容区域获取内容对应的位置的数据（然后实现跳转功能即可）

      /**
       * 点击内容那个TextView对应的调用
       * @param onContentListener
       */
        public void setOnContentListener(OnItemContentClickListener 
      onContentListener){
       this.mOnItemContentClickListener=onContentListener;
      }
- 最后在Activity中进行调用了

       mAdapter.setOnContentListener(new 
      CustomAdapter.OnItemContentClickListener() {
    @Override
   public void OnContentClick(int position) {
    ToastUtils.showMessage(ThirdActivity.this,
   ​               getResources().getString(R.string.click_item_content));
   ​    }

            @Override
            public void OnContentLongClick(int position) {
       
            }
        });
- 可以看到这里是采用匿名内部来的方式来实现的，这样写可以更直观一点，但是看着比较乱一点（仁者见仁，智者见智）

### 最后
- 当然，自定义接口还有很多写法，还需要大家去探索，我这里只是抛砖引玉。
 - 针对自定义接口今天就讲到这里，希望对大家有所帮助，如果有哪里讲的不到位的地方，还请大家见谅，并且告诉我一声，谢谢。