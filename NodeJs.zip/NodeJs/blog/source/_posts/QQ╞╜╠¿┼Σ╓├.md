---
title: QQ平台配置
categories: 平台配置
---

集成乐推的QQ登录功能需要在腾讯开放平台申请appid和appkey，如果需要QQ登录功能需要腾讯开放平台审核通过

1、[腾讯开放平台入口](https://open.tencent.com/)  用QQ号登录就可以了
2、在“应用开放平台”选择“应用接入”
![image](https://upload-images.jianshu.io/upload_images/1716569-7ee1fdb94085ab5d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

3、跳转到管理中心页面，腾讯开放平台已经给定了appid和appkey，在这个appid和appkey下创建应用。
选择android/ios/web应用，以android为例，点击创建应用，在弹出的弹框“选择安卓应用类型”（根据您所开发的应用实际选择），点击确定。

![image](https://upload-images.jianshu.io/upload_images/1716569-1317ff6c4204c701.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)![image](https://upload-images.jianshu.io/upload_images/1716569-ea87eb760a950f45.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


4、点击确定后跳转到应用完善界面根据要求填写星号必填项
（1）基本信息

![image](https://upload-images.jianshu.io/upload_images/1716569-0ae5ba69487bdc1f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


（2）安装包
点“+”选择apk文件，应用需要加固才能审核通过，腾讯开放平台有给出加固的流程，可按照要求加固apk
应用包上传好之后有需要选择发布类型，如果您的应用已经可以发布上架选择“审核通过后立即发布”就可以了，如果应用还未完善不需要发布，选择“定时发布”

![image](https://upload-images.jianshu.io/upload_images/1716569-00915f3ea00d1e30.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


（3）图片素材，注意图片大小、尺寸、格式

![image](https://upload-images.jianshu.io/upload_images/1716569-edfe29701107947f.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


（4）适配信息，支持屏幕大小、支持语言、资费类型等都根据自己应用的要求按实际情况填写
![image](https://upload-images.jianshu.io/upload_images/1716569-3dd9fce2c24f4069.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


（5）版权证明
![image](https://upload-images.jianshu.io/upload_images/1716569-84586ed84b85a08d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

 

5、信息都填写好之后提交审核
![image](https://upload-images.jianshu.io/upload_images/1716569-00097f9ea3cf9fab.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


6、管理中心>安卓应用,可以看到appid和appkey的值，复制到您的工程中配置QQ平台信息的地方

![image](https://upload-images.jianshu.io/upload_images/1716569-937680a13d75df30.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


如果需要QQ登录功能提交审核之后需耐心等待腾讯官方审核，审核通过之后您在腾讯开放平台上传的应用包的签名需要和您工程打包之后得到的签名是一致的才能登录成功！