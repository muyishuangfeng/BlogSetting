---
title: Git用法初探
categories: Git
---

## 前提

之前一直在用svn和cvs，感觉跟不上时代的潮流了，加上git优点多多，所以就抽出时间进行了git基本的学习，一是怕自己忘记了，另外一个希望可以帮助到新手，避免走弯路，如有不对的地方还望指正。

## 简介

Git是一个开源的分布式版本控制系统，可以有效、高速的处理从很小到非常大的项目版本管理。 Git 是 Linus Torvalds 为了帮助管理 Linux 内核开发而开发的一个开放源码的版本控制软件。 Torvalds 开始着手开发 Git 是为了作为一种过渡方案来替代 BitKeeper，后者之前一直是 Linux 内核开发人员在全球使用的主要源代码工具。开放源码社区中的有些人觉得BitKeeper 的许可证并不适合开放源码社区的工作，因此 Torvalds 决定着手研究许可证更为灵活的版本控制系统。尽管最初 Git 的开发是为了辅助 Linux 内核开发的过程，但是我们已经发现在很多其他自由软件项目中也使用了 Git。

## 优势

1、*版本库本地化 支持离线提交，相对独立不影响协同开发*

```
   每个开发者都拥有自己的版本控制库，在自己的版本库上可以任意的执行提交代码、创建分支等行为。
 例如，开发者认为自己提交的代码有问题？没关系，因为版本库是自己的，回滚历史、反复提交、
 归并分支并不会影响到其他开发者。

```

2、*更少的“仓库污染”*

```
    git对于每个工程只会产生一个.git目录，这个工程所有的版本控制信息都在这个目录中，
 不会像SVN那样在每个目录下都产生.svn目录。

```

3、*把内容按元数据方式存储，完整克隆版本库*

```
     所有版本信息位于.git目录中，它是处于你的机器上的一个克隆版的版本库，
  它拥有中心版本库上所有的东西，例如标签、分支、版本记录等。

```

4、*支持快速切换分支方便合并，比较合并性能好*

```
 在同一目录下即可切换不同的分支，方便合并，且合并文件速度比SVN快。

```

5、*分布式版本库，无单点故障，内容完整性好*

```
    内容存储使用的是SHA-1哈希算法。这能确保代码内容的完整性，
 确保在遇到磁盘故障和网络问题时降低对版本库的破坏。

```

## git安装

* 1、Linux安装

  ```
  直接在终端输入 sudo apt-get install git-core
  
  ```

* 2、windows安装 

     首先进入[官网](https://git-scm.com/)下载对应版本，然后在下路路径下点击刚才下载的exe文件一直默认安装即可。

## git使用（主要针对windows）

* 1、配置身份(windows打开GitBash，Linux打开shell)——(提交代码的时候就知道是谁提交的)如下所示:）

  ```
  git config --global user.name "Your Name"
  git config --global user.email "Your email"
  
  ```

       配置完成之后同样的输入 
       git config --global user.name和
       git config --global user.email 
       即可看到用户名和邮箱

* 2、创建代码仓库

      进入到你需要创建仓库的目录直接在Git Bash中输入git init  
      即可创建完之后会在你创建仓库的目录下生成一个隐藏的.git文件夹，
      这个文件夹就是用来记录本地所有的Git操作的（如果想删除仓库直接删除.git文件夹即可）。

* 3、提交本地代码（分为两步add 和commit）

  * add添加文件

    ```
        add是将需要提交的代码先添加进来，commit则是真正的提交操作。
      比如我们在D盘的Project下面有一个Test文件夹和Hello world文件，如果想提交Hello world文件，
      则需要先添加——命令如下：
       git add Hello world
      如果想添加整个D盘整个Project文件夹下的Test文件夹则可以这样写:
       git add Project
      如果你还是觉得复杂还可以这样写(将Project文件夹下的所有文件夹进行添加):
       git add .
    
    ```

  * commit提交文件

    ```
    上面的已经将文件添加好了，我们来提交一下，命令如下:
     git commit -m "First commit."
    
    ```

*注意 ：* 在commit命令的后面一定要通过-m参数来加上提交的描述信息，没有描述信息的提交被认为是不合法的。

* 4、忽略文件

         Git提供了一种可配置性很强的机制允许用户将指定的文件或目录排除在版本控制之外，
      他回检查代码仓库的根目录下是否存在一个名为.gitignore的文件，如果存在的话就去一行
      行读取这个文件的内容，并把每一行指定的文件或目录排除在版本控制之外。

  *注意 :* .gitignore中指定的文件或目录是可以使用星(*)通配符的。


     在终端输入 Hello world/ 
   这样就表示把 Hello world文件忽略掉了，然后使用add命令进行添加
   git add .
   然后执行commit命令完成提交
   git commit -m "Sencond commit."

  

* 5、查看修改内容（使用status命令就可以了命令如下：）

  ```
  git status
  
  ```

* 6、 查看更改内容

  * 1、查看所有文件的更改内容

    ```
    git diff
    
    ```

  * 2、查看单个文件的更改内容

    ```
    git diff d:Project/Hello world.txt
    
    ```

* 7、撤销未提交的修改

  ```
  比如我们D盘Project目录下的Hello world 原来内容为123，我们修改为456
  ，然后想撤销修改我们可以使用checkout命令,如下：
  git checkout d:Project/Hello world.txt
  然后重新输入git status即可查看结果（这种只能针对没有执行 git add命令的文件)如果执行了add 命令的
  就不能取消了吗？当然不是，如果想要执行撤销命令先要取消添加，才能执行撤销提交。取消命令是reset，如下所示：
  git reset HEAD d:Project/Hello world.txt
  
  ```

* 8、查看提交记录（可以使用log命令查看历史提交记录)

  ```
   git log（查看所有的提交记录)
  
  ```

  * +   比如我们的id是123，那么查看具体的命令如下：

      ```
      git log 123 （查看id为123的具体的提交记录）
    
      ```

  * +  查看一行提交记录呢，命令如下：(命令是-1)

      ```
       git log 123 -1
    
      ```

  * +  如果想查看修改的具体内容呢，命令如下：(命令是-p)

      ```
      git log 123 -1 -p
    
      ```

* 9、git分支

  * 1、查看分支

    ```
    git branch -a
    
    ```

  * 2、创建分支

    ```
    git branch "分支名称"
    
    ```

  * 3、切换分支

    ```
    git checkout “分支名称"
    
    ```

  * 4、合并分支到主干上

    ```
     git checkout master
     git merge "分支名称"
    
    ```

  * 5、删除分支

    ```
     git branch -D 分支名称
    
    ```

* 10、与远程版本库协作

  * 1、下载代码到本地(clone)

    ```
     git clone "地址“
    
    ```

  * 2、提价代码到远程库(push)

      git push origin master （其中origin指定的是远程版本库的Git地址，master指同步到那个分支上)

  * 3、同步远程版本库的代码到本地(fetch)

        git fetch origin master

  * 4、查看远程版本库修改了那些东西

        git diff origin/master

  * 5、分支上的修改合并到主干上

        git merge origin/master

  * 6、从远程库同步最新的代码并且合并到本地

        git pull origin/master

## 感谢

[Git的优势和用法](http://blog.csdn.net/dengsilinming/article/details/7999188)

## 关于我

[Silence潇湘夜雨](https://www.jianshu.com/u/1e2eec6f972c)

[码云](https://gitee.com/1032200695/events)

[github](https://github.com/muyishuangfeng)

[掘金](https://juejin.im/user/58df0abf61ff4b006b115e43)

[个人博客](https://muyishuangfeng.github.io/)