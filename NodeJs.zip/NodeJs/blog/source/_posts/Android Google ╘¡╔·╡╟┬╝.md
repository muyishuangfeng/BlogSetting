---
title: Android Google 原生登录
categories: 登录
---

###　前言：

　　之前写过[Android Facebook原生登录](https://www.jianshu.com/p/71b5d3739cd6)，想着既然Facebook登录已经写了，索性把Google 登录也写一下，做一下记录。
####　首先
　　要集成Google登录前首先需要查阅[官方文档](https://developers.google.com/identity/sign-in/android/start?hl=zh-cn)，当然这个是需要自备梯子的。
​      
  + 1、查看官方demo
       如果你是第一次使用Google登录，那么，最简单的方式当然是查看官方文档和官方demo了。

        $ git clone https://github.com/googlesamples/google-services.git
  + 2、配置登录需要的配置
     ![Google登录配置.png](https://upload-images.jianshu.io/upload_images/1716569-9e94060d48fc2c09.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

__注意:Google登录什么需要的客户端ID是web端的ID__

#### 其次

   + 1、开始Google登录的接入
     在app下的build.gradle的dependencies 节点下配置Google服务

    dependencies {
    implementation 'com.google.android.gms:play-services-auth:16.0.0'
    }

+ 2、Google登录方法的封装



    public class GoogleLoginManager {
    
    private static final String TAG = GoogleLoginManager.class.getSimpleName();
     /**
      * 初始化登录
      *@params contenxt 上下文
      *@params clientID Google配置分配的客户端ID
      *@params selfRequestCode 自定义请求码
      */
    public static void initGoogle(Activity context, String clientID, int selfRequestCode) {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(clientID)
                .requestEmail()
                .build();
        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(context, gso);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        context.startActivityForResult(signInIntent, selfRequestCode);
    }
    
       /**
      * 登录回调
      *@params requestCode 对应onActivityResult的 requestCode
      *@params data 对应onActivityResult的 data
      *@params selfRequestCode 对应上面初始化请求的自定义请求码
      *@params mListener 登录结果回调
      */
    public static void onActivityResult(int requestCode, Intent data, int selfRequestCode,
                                        OnLoginSuccessListener mListener) {
        if (requestCode == selfRequestCode) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult( task, mListener);
        }
    }


    private static void handleSignInResult(@NonNull Task<GoogleSignInAccount> completedTask,
                                           OnLoginSuccessListener mListener) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            String idToken = account.getIdToken();
            Log.e(TAG, idToken);
            mListener.onSuccessResult(idToken);
        } catch (ApiException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 退出登录
     */
    public static void GoogleSingOut(Context context, String clientID, final OnGoogleSignOutListener mListener) {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(clientID)
                .requestEmail()
                .build();
        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(context, gso);
        mGoogleSignInClient.signOut().addOnCompleteListener((Activity) context, new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                mListener.onSignOutSuccess();
            }
        });
      }
    
    }

 




     /**
      * 退出登录接口
      */
     public interface OnGoogleSignOutListener {
    
     void onSignOutSuccess();
    
     }
     /**
      * 登录回调接口
      */
     public interface OnLoginSuccessListener {
    
     void onSuccessResult(String result);
    
     }

### 最后


 好了，上面就是Google登录所需要的所有东西了。__完整的登录流程应该是这样的：从Google获取idToken，然后发送到自己的服务器，在服务器验证通过后再回调给客户端。__

### 感想

  最近一直在写国外的项目，接触的都是英文文档，在此时才看到自己的英文水平是多么的差，没事还是需要多看看英文的东西。提升下自己的英文水平，以后看到英文文档不至于太头疼。如果想了解更多或者有什么不懂的地方，可以加群__493180098__。
嗯，下一篇可能会写__Google支付__或者韩国的支付平台__OneStore支付__