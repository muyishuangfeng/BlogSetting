---
title: SDK 登录说明
keywords: 博客文章密码
password:  123123	
abstract: 请输入密码查看文章详情
message:  输入密码，查看文章
---




### google登录接入说明


+ 1、在project 下的build 导入仓库地址

       maven {
        url "https://jitpack.io"
        credentials { username authToken }
   -    }
+ 2 、在 $HOME/.gradle/gradle.properties 文件下添加 token

       authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 3、在moudle下面的build文件下添加网络库依赖
   ​     

       implementation 'com.github.muyishuangfeng:LTGameSDKGoogle-Android:1.0.3'
+ 4、在moudle的build文件夹下的android --->defaultConfig 相关配置

      defaultConfig {
        ...
       
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
      }

__1、初始化参数说明__ 

|         参数         |   类型    | 是否必须 | 说明                     |
| :------------------: | :-------: | :------: | :----------------------- |
|        debug         |  boolean  |    否    | 是否开启debug模式        |
|       LT-AppID       |  String   |    是    | 每个应用对应的appid      |
|       LTAppKey       |  String   |    是    | 每个应用对应的appKey     |
|       baseUrl        |  String   |    是    | 根据具体服务器配置       |
|      packageId       |  String   |    是    | 每个应用的包名           |
|       clientID       |  String   |    是    | Google平台配置的客户端ID |
|        mAdID         |  String   |    是    | 广告ID（获取方法看文档） |
|     requestCode      |    int    |    是    | 支付请求码               |
|        Target        |    int    |    是    | 是否开启Google登录       |
|     LoginObject      |   bean    |    是    | 登录配置的参数           |
| OnLoginStateListener | Interface |    是    | 登录回调接口             |

__2、支付调用方式__

+ 1、初始化（刚进入应用或者支付页面的时候配置）

      private void init() {
        LTGameOptions options = new LTGameOptions.Builder(this)
                .debug(true)
                .appID(LTAppID)
                .appKey(LTAppKey)
                .baseUrl(baseUrl)
                .setAdID(mAdID)
                .packageID(mPackageID)
                .google(clientID)
                .requestCode(REQUEST_CODE)
                .build();
        LTGameSdk.init(options);
      }

 + 2、接口回调（可以写成匿名内部类的方式也可以写成全局方式）

      OnLoginStateListener mOnLoginListener = new OnLoginStateListener() {

    @Override
      public void onState(Activity activity, LoginResult result) {
      switch (result.state) {
       case LoginResult.STATE_SUCCESS:
        Log.e(TAG, result.getResultModel().toString());
        mTxtResult.setText(result.getResultModel().toString());
        break;
        }
        }
    
        };




  + 3、登录开始


      LoginObject object = new LoginObject();
      object.setBaseUrl(baseUrl);//服务器url
      object.setmAdID(mAdID);//唯一ID（广告ID）
      object.setLTAppID(LTAppID);//乐推AppID
      object.setLTAppKey(LTAppKey);//乐推AppKey
      object.setmGoogleClient(clientID);//客户端ID
      object.setSelfRequestCode(REQUEST_CODE);//请求码
      object.setLoginOut(false);//是否清空登录信息重新登录
      object.setmPackageID(mPackageID);//包名
      LoginManager.login(GoogleActivity.this, Target.LOGIN_GOOGLE,      object, mOnLoginListener);

 + 4、结果码（具体以接口回调结果为准）


       //开始
       STATE_START
       //成功
       STATE_SUCCESS 
       //失败
       STATE_FAIL
       //取消
       STATE_CANCEL
       //完成
       STATE_COMPLETE 
       //有效
       STATE_ACTIVE 

__注意：LoginResult__ 附带有登录结果 __result.getResultModel().toString()__为具体信息

#### Facebook登录说明

__注意:如果在project下的build文件和在 $HOME/.gradle/gradle.properties 文件下添加了 token，请忽略1、2配置，直接看3和4__
  + 1、在project 下的build 导入仓库地址

              maven {

       url "https://jitpack.io"
        credentials { username authToken }
       }
+ 2 、在 $HOME/.gradle/gradle.properties 文件下添加 token

       authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 3、在moudle下面的build文件下添加网络库依赖
  ​     

       implementation 'com.github.muyishuangfeng:LTGameSDKFacebook-Android:1.0.2'
+ 4、在moudle的build文件夹下的android --->defaultConfig 和 android--->buildTypes 下的release 和 debug下面配置 Facebook ID和scheme

        defaultConfig {
        ...
        manifestPlaceholders = [Facebook_app_id         : "xxx",//FacebookID（Facebook申请的ApplicationId）
                                fb_login_protocol_scheme: "xxx"]//FacebookScheme
        
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
         }
        
         buildTypes {
          release {
         ...
         signingConfig signingConfigs.config
          manifestPlaceholders = [Facebook_app_id         :    "xx",//FacebookID（Facebook申请的ApplicationId）
          fb_login_protocol_scheme: "xxx"]//FacebookScheme
        
        }
        debug {
            signingConfig signingConfigs.config
            manifestPlaceholders = [Facebook_app_id         : "xx",//FacebookID（Facebook申请的ApplicationId）
                                    fb_login_protocol_scheme: "xxx"]//FacebookScheme
        }
      }

__1、初始化参数说明__ 

|         参数         |   类型    | 是否必须 | 说明                     |
| :------------------: | :-------: | :------: | :----------------------- |
|        debug         |  boolean  |    否    | 是否开启debug模式        |
|       LT-AppID       |  String   |    是    | 每个应用对应的appid      |
|       LTAppKey       |  String   |    是    | 每个应用对应的appKey     |
|       baseUrl        |  String   |    是    | 根据具体服务器配置       |
|      packageId       |  String   |    是    | 每个应用的包名           |
|       clientID       |  String   |    是    | Google平台配置的客户端ID |
|        mAdID         |  String   |    是    | 广告ID（获取方法看文档） |
|     requestCode      |    int    |    是    | 支付请求码               |
|        Target        |    int    |    是    | 是否开启Google登录       |
|     LoginObject      |   bean    |    是    | 登录配置的参数           |
| OnLoginStateListener | Interface |    是    | 登录回调接口             |

__2、登录调用方式__

+ 1、初始化（刚进入应用或者支付页面的时候配置）

      private void init() {
        LTGameOptions options = new LTGameOptions.Builder(this)
                .debug(true)
                .appID(LTAppID)
                .appKey(LTAppKey)
                .baseUrl(baseUrl)
                .setAdID(mAdID)
                .packageID(mPackageID)
                .facebookEnable()
                .requestCode(REQUEST_CODE)
                .build();
        LTGameSdk.init(options);
      }

 + 2、接口回调（可以写成匿名内部类的方式也可以写成全局方式）



       OnLoginStateListener mOnLoginListener = new   OnLoginStateListener() {
    
      @Override
       public void onState(Activity activity, LoginResult result) {
       switch (result.state) {
       case LoginResult.STATE_SUCCESS:
       Log.e(TAG, result.getResultModel().toString());
       mTxtResult.setText(result.getResultModel().toString());
       break;
         }
       }
    
        };

  + 3、登录开始


      LoginObject object = new LoginObject();
      object.setBaseUrl(baseUrl);//服务器url
      object.setmAdID(mAdID);//唯一ID（广告ID）
      object.setLTAppID(LTAppID);//乐推AppID
      object.setLTAppKey(LTAppKey);//乐推AppKey
      object.setFacebookAppID("xxx");//Facebook的ApplicationID
      object.setSelfRequestCode(REQUEST_CODE);//请求码
      object.setLoginOut(false);//是否清空登录信息重新登录
      object.setmPackageID(mPackageID);//包名
      LoginManager.login(GoogleActivity.this, Target.LOGIN_GOOGLE, object, mOnLoginListener);

 + 4、结果码（具体以接口回调结果为准）

        //开始
        STATE_START
        //成功
        STATE_SUCCESS 
        //失败
        STATE_FAIL
        //取消
        STATE_CANCEL
        //完成
        STATE_COMPLETE 
        //有效
        STATE_ACTIVE 

__注意：LoginResult__ 附带有登录结果 __result.getResultModel().toString()__为具体信息

#### UI登录
##### 前提（如果集成了UI包就不需要集成Google和Facebook包，UI包里面默认集成了Google和Facebook两种登录方式只需要集成UI包就可以）

__注意:如果在project下的build文件和在 $HOME/.gradle/gradle.properties 文件下添加了 token，请忽略1、2、4配置，直接看3__
+ 1、在project 下的build 导入仓库地址

       maven {
        url "https://jitpack.io"
        credentials { username authToken }
      }
+ 2 、在 $HOME/.gradle/gradle.properties 文件下添加 token

       authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 3、在moudle下面的build文件下添加网络库依赖
   ​     

       implementation 'com.github.muyishuangfeng:LTGameKoreaSDKUI-Android:1.0.1'
+ 4、在moudle的build文件夹下的android --->defaultConfig 相关配置

      defaultConfig {
        ...
       
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
      }

#### 参数说明

+ 1、登录方法

  |         参数          |   类型    | 是否必须 | 说明                     |
  | :-------------------: | :-------: | :------: | :----------------------- |
  |       activity        |  Context  |    是    | 上下文                   |
  |        baseUrl        |  String   |    是    | 根据具体服务器配置       |
  |     mAgreementUrl     |  String   |    是    | 用户协议url              |
  |      mPrivacyUrl      |  String   |    是    | 隐私政策url              |
  |    googleClientID     |  String   |    是    | google客户端ID           |
  |        LTAppID        |  String   |    是    | 乐推AppID                |
  |       LTAppKey        |  String   |    是    | 乐推AppKey               |
  |         mAdID         |  String   |    是    | 广告ID（获取方法看文档） |
  |      mPackageID       |  String   |    是    | 包名                     |
  |      mIsLoginOut      |  boolean  |    是    | 是否清除登录信息重新登录 |
  | OnResultClickListener | Interface |    是    | 首次登录数据回调接口     |
  |  OnReLoginInListener  | Interface |    是    | 第二次登录数据回调接口   |

+ 2、登出方法

  |         参数          |   类型    | 是否必须 | 说明                     |
  | :-------------------: | :-------: | :------: | :----------------------- |
  |       activity        |  Context  |    是    | 上下文                   |
  |        baseUrl        |  String   |    是    | 根据具体服务器配置       |
  |      mFacebookID      |  String   |    是    | Facebook的ApplicationID  |
  |     mAgreementUrl     |  String   |    是    | 用户协议url              |
  |      mPrivacyUrl      |  String   |    是    | 隐私政策url              |
  |    googleClientID     |  String   |    是    | google客户端ID           |
  |        LTAppID        |  String   |    是    | 乐推AppID                |
  |       LTAppKey        |  String   |    是    | 乐推AppKey               |
  |         mAdID         |  String   |    是    | 广告ID（获取方法看文档） |
  |      mPackageID       |  String   |    是    | 包名                     |
  |      mIsLoginOut      |  boolean  |    是    | 是否清除登录信息重新登录 |
  | OnResultClickListener | Interface |    是    | 登出重新登录数据回调接口 |

#### 方法调用
   + 1、登录方法


      private void login() {
        LoginUIManager.getInstance().loginIn(UIActivity.this, baseUrl,   mFacebookID,mAgreementUrl, mPrivacyUrl, clientID,LTAppID, LTAppKey, mAdID, mPackageID, false, new OnResultClickListener() {
        
     @SuppressLint("SetTextI18n")
     @Override
     public void onResult(ResultData result) {
     mTxtResult.setText("First Login=============" + result.toString());
       Log.e("ResultData", result.toString());
      }
     }, new OnReLoginInListener() {
     @Override
      public void OnLoginResult(ResultData result) {
        mTxtResult.setText("Second Login============="  +result.toString());
      }
    });
    }
+ 2、登出方法

      private void loginOut() {
        LoginUIManager.getInstance().loginOut(this, baseUrl, mFacebookID, mAgreementUrl,
                mPrivacyUrl, clientID, LTAppID, LTAppKey, mAdID, mPackageID, true,
                new OnResultClickListener() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onResult(ResultData result) {
                        mTxtResult.setText("退出重新登录=============" +result.toString());
                    }
                });
       }
  =================================================================================
  ​     **注意:广告ID必须写，获取广告ID的方法如下**

      Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                try {
                  String  mAdID = DeviceUtils.getGoogleAdId(Context上下文);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });




 __注意：兼容Android9.0 Http请求的网络请求方式__

 + 1、在res目录下创建xml文件夹
 + 2、在xml文件夹下创建network_security_config.xml文件夹


          <?xml version="1.0" encoding="utf-8"?>
          <network-security-config>
          <base-config cleartextTrafficPermitted="true" />
          </network-security-config>
 + 3、在清单文件（AndroidManifest）中的Application节点下配置引用


       <application
       android:networkSecurityConfig="@xml/network_security_config"
       />

#### 手机登录

__注意:如果在project下的build文件和在 $HOME/.gradle/gradle.properties 文件下添加了 token，请忽略1、2、4配置，直接看3__
+ 1、在project 下的build 导入仓库地址

       maven {
        url "https://jitpack.io"
        credentials { username authToken }
         }
+ 2 、在 $HOME/.gradle/gradle.properties 文件下添加 token
  
       authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 3、在moudle下面的build文件下添加网络库依赖
   ​     

       implementation 'com.github.muyishuangfeng:LTGameSDKPhone-Android:1.0.0'
+ 4、在moudle的build文件夹下的android --->defaultConfig 相关配置
  
      defaultConfig {
        ...
       
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
      }

#### 参数说明

+ 1、登录方法

  |参数|类型|是否必须|说明|
  |:------:|:------:|:-----:|:------|
  |activity| Context|是|上下文|
  |baseUrl|String|是|根据具体服务器配置|
  |LTAppID|String|是|乐推AppID|
  |LTAppKey|String|是|乐推AppKey|
  |mAdID|String|是|广告ID（获取方法看文档）|
  |mPhone|String|是|手机号|
  |mPassword|String|是|密码|
  |loginCode|String|是|登录标记（固定值是2）|
  |OnLoginStateListener|Interface|是|登录数据回调接口|

 + 2、注册方法

|参数|类型|是否必须|说明|
|:------:|:------:|:-----:|:------|
|activity| Context|是|上下文|
|baseUrl|String|是|根据具体服务器配置|
|LTAppID|String|是|乐推AppID|
|LTAppKey|String|是|乐推AppKey|
|mAdID|String|是|广告ID（获取方法看文档）|
|mPhone|String|是|手机号|
|mPassword|String|是|密码|
|loginCode|String|是|登录标记（固定值是1）|
|OnLoginStateListener|Interface|是|登录数据回调接口|

+ 3、修改密码方法

  |参数|类型|是否必须|说明|
  |:------:|:------:|:-----:|:------|
  |activity| Context|是|上下文|
  |baseUrl|String|是|根据具体服务器配置|
  |LTAppID|String|是|乐推AppID|
  |LTAppKey|String|是|乐推AppKey|
  |mAdID|String|是|广告ID（获取方法看文档）|
  |mPhone|String|是|手机号|
  |mPassword|String|是|新密码|
  |loginCode|String|是|登录标记（固定值是3）|
  |OnLoginStateListener|Interface|是|登录数据回调接口|


#### 方法调用

   + 1、初始化（刚进入应用或者支付页面的时候配置）


          private void init() {
    
        LTGameOptions options = new LTGameOptions.Builder(this)
          .debug(true)
          .appID(LTAppID)
          .appKey(LTAppKey)
          .baseUrl(baseUrl)
          .setAdID(mAdID)
          .loginCode("1")//登录标记默认设为1
          .phoneAndPass(mPhone, mPassword)
          .phoneEnable()
          .build();
          LTGameSdk.init(options);
         }

 + 2、接口回调（可以写成匿名内部类的方式也可以写成全局方式）


       OnLoginStateListener  mOnLoginListener = new OnLoginStateListener() {
     @Override
    public void onState(Activity activity, LoginResult result) {
    switch (result.state) {
    case LoginResult.STATE_SUCCESS:
    Log.e(TAG,result.getResultModel().toString());
    mTxtResult.setText(result.getResultModel().toString());
    break;
    case LoginResult.STATE_FAIL:
    Log.e(TAG, "STATE_FAIL");
     break;
       }
      }
      };

+ 3 登录方法调用


      LoginObject object = new LoginObject();
                object.setBaseUrl(baseUrl);//服务器url
                object.setmAdID(mAdID);//广告ID
                object.setLTAppID(LTAppID);//乐推appID 
                object.setLTAppKey(LTAppKey);//乐推appKey
                object.setmPhone(mPhone);//手机号
                object.setmPassword(mPassword);//密码
                object.setmLoginCode("2");//登录标记
                LoginManager.login(PhoneActivity.this, Target.LOGIN_PHONE, object, mOnLoginListener);

+ 3 注册方法调用

      LoginObject object = new LoginObject();
                object.setBaseUrl(baseUrl);//服务器url
                object.setmAdID(mAdID);//广告ID
                object.setLTAppID(LTAppID);//乐推appID 
                object.setLTAppKey(LTAppKey);//乐推appKey
                object.setmPhone(mPhone);//手机号
                object.setmPassword(mPassword);//密码
                object.setmLoginCode("1");//登录标记
                LoginManager.login(PhoneActivity.this, Target.LOGIN_PHONE, object, mOnLoginListener);

+ 4修改密码方法调用

      LoginObject object = new LoginObject();
                object.setBaseUrl(baseUrl);//服务器url
                object.setmAdID(mAdID);//广告ID
                object.setLTAppID(LTAppID);//乐推appID 
                object.setLTAppKey(LTAppKey);//乐推appKey
                object.setmPhone(mPhone);//手机号
                object.setmPassword(mNewPassword);//新密码
                object.setmLoginCode("3");//登录标记
                LoginManager.login(PhoneActivity.this, Target.LOGIN_PHONE, object, mOnLoginListener);

### 方法回调

    1、200（“OK”） 成功
    2、400 （“NO"）失败


### QQ 登录说明


__注意:如果在project下的build文件和在 $HOME/.gradle/gradle.properties 文件下添加了 token，请忽略1、2配置，直接看3和4__
  + 1、在project 下的build 导入仓库地址

              maven {

                  url "https://jitpack.io"
                 credentials { username authToken }
             }
+ 2 、在 $HOME/.gradle/gradle.properties 文件下添加 token

       authToken=jp_vut53cpq7p6ot31plvu1esqa7r
+ 3、在moudle下面的build文件下添加网络库依赖
  ​     

       implementation 'com.github.muyishuangfeng:LTGameSDKQQ-Android:1.0.0'
+ 4、在moudle的build文件夹下的android --->defaultConfig 和 android--->buildTypes 下的release 和 debug下面配置 Facebook ID和scheme

        defaultConfig {
        ...
        manifestPlaceholders = [...
                                QQAppID: "xxx"]//QQAppID
        
        javaCompileOptions {
            annotationProcessorOptions {
                includeCompileClasspath false
            }
        }
         }
        
         buildTypes {
          release {
         ...
         signingConfig signingConfigs.config
         manifestPlaceholders = [...
                                QQAppID: "xxx"]//QQAppID
        
        }
        debug {
            signingConfig signingConfigs.config
            manifestPlaceholders = [...
                                QQAppID: "xxx"]//QQAppID
        }
      }

__1、初始化参数说明__ 

|         参数         |   类型    | 是否必须 | 说明                     |
| :------------------: | :-------: | :------: | :----------------------- |
|        debug         |  boolean  |    否    | 是否开启debug模式        |
|       LT-AppID       |  String   |    是    | 每个应用对应的appid      |
|       LTAppKey       |  String   |    是    | 每个应用对应的appKey     |
|       baseUrl        |  String   |    是    | 根据具体服务器配置       |
|      mQQAppID|  String   |    是    | QQ平台申请的AppID           |
|        mAdID         |  String   |    是    | 广告ID（获取方法看文档） |
|     qQEnable|    boolean    |    是    | 是否开启QQ登录               |
|        Target        |    int    |    是    | 是否开启Google登录       |
|     loginOut|   boolean|    是    | 是否退出登录（true：是，false：否）        |
| OnLoginStateListener | Interface |    是    | 登录回调接口             |

__2、登录调用方式__

+ 1、初始化（刚进入应用或者支付页面的时候配置）

      private void init() {
        LTGameOptions options = new LTGameOptions.Builder(this)
                .debug(true)
                .appID(LTAppID)
                .appKey(LTAppKey)
                .baseUrl(baseUrl)
                .setAdID(mAdID)
                .setQQEnable(true)
                .qq(mQQAppID)
                .build();
        LTGameSdk.init(options);
      }

 + 2、接口回调（可以写成匿名内部类的方式也可以写成全局方式）



       OnLoginStateListener mOnLoginListener = new OnLoginStateListener() {
            @Override
            public void onState(Activity activity, LoginResult result) {
                switch (result.state) {
                    case LoginResult.STATE_SUCCESS:
                        Log.e(TAG, result.getResultModel().toString());
                        mTxtResult.setText(result.getResultModel().toString());
                        break;
    
                    case LoginResult.STATE_FAIL:
                        Log.e(TAG,result.getError().toString());
                        Log.e(TAG, "STATE_FAIL");
                        break;
                    case LoginResult.STATE_CANCEL:
                        Log.e(TAG, "STATE_FAIL");
                        break;
    
                }
            }
    
        };

  + 3、登录开始


     LoginObject object = new LoginObject();
                object.setBaseUrl(baseUrl);//服务器url
                object.setmAdID(mAdID);//唯一广告ID
                object.setLTAppID(LTAppID);乐推AppID
                object.setLTAppKey(LTAppKey);//乐推AppKey
                object.setQqAppID(mQQAppID);//qq平台申请的AppID
                object.setLoginOut(false);//是否退出，true：是，false：否
                LoginManager.login(QQActivity.this, Target.LOGIN_QQ, object, mOnLoginListener);

 + 4、结果码（具体以接口回调结果为准）

        //开始
        STATE_START
        //成功
        STATE_SUCCESS 
        //失败
        STATE_FAIL
        //取消
        STATE_CANCEL
        //完成
        STATE_COMPLETE 
        //有效
        STATE_ACTIVE 

__注意：LoginResult__ 附带有登录结果 __result.getResultModel().toString()__为具体信息







